import { useCallback, useEffect, useMemo, useRef, useState } from "react";

/** Adds an `in` class when the element scrolls into view (once). */
export function useReveal<T extends HTMLElement = HTMLDivElement>(
  options?: { threshold?: number; rootMargin?: string },
) {
  const ref = useRef<T | null>(null);
  const [shown, setShown] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (typeof IntersectionObserver === "undefined") {
      setShown(true);
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            setShown(true);
            io.unobserve(e.target);
          }
        });
      },
      {
        threshold: options?.threshold ?? 0.18,
        rootMargin: options?.rootMargin ?? "0px 0px -8% 0px",
      },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [options?.threshold, options?.rootMargin]);

  return { ref, shown, cls: shown ? "in" : "" };
}

/** Count from 0 → target when `active` flips true. */
export function useCountUp(target: number, active: boolean, duration = 1500) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    if (!active) return;
    let raf = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setValue(Math.round(target * eased));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, active, duration]);
  return value;
}

const GLYPHS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ#%&*+/<>_";

/** Cycles a word list with a scramble-decode transition. */
export function useScramble(words: string[], hold = 2200) {
  const [text, setText] = useState(words[0] ?? "");
  const iRef = useRef(0);
  const frame = useRef(0);
  const raf = useRef(0);

  useEffect(() => {
    if (words.length < 2) return;
    let alive = true;

    const scrambleTo = (next: string) => {
      cancelAnimationFrame(raf.current);
      frame.current = 0;
      const total = 26;
      const step = () => {
        if (!alive) return;
        frame.current += 1;
        const progress = frame.current / total;
        const out = next
          .split("")
          .map((ch, i) => {
            if (ch === " ") return " ";
            if (i / next.length < progress) return ch;
            return GLYPHS[Math.floor(Math.random() * GLYPHS.length)];
          })
          .join("");
        setText(out);
        if (frame.current < total) raf.current = requestAnimationFrame(step);
        else setText(next);
      };
      raf.current = requestAnimationFrame(step);
    };

    const id = window.setInterval(() => {
      iRef.current = (iRef.current + 1) % words.length;
      scrambleTo(words[iRef.current]);
    }, hold);

    return () => {
      alive = false;
      cancelAnimationFrame(raf.current);
      window.clearInterval(id);
    };
  }, [words, hold]);

  return text;
}

/** Magnetic hover: element drifts toward the pointer. */
export function useMagnetic<T extends HTMLElement = HTMLButtonElement>(strength = 0.32) {
  const ref = useRef<T | null>(null);
  const [offset, setOffset] = useState({ x: 0, y: 0 });

  const onMove = useCallback(
    (e: React.MouseEvent) => {
      const el = ref.current;
      if (!el || !finePointer()) return;
      const r = el.getBoundingClientRect();
      setOffset({
        x: (e.clientX - (r.left + r.width / 2)) * strength,
        y: (e.clientY - (r.top + r.height / 2)) * strength,
      });
    },
    [strength],
  );

  const reset = useCallback(() => setOffset({ x: 0, y: 0 }), []);

  return { ref, style: { transform: `translate3d(${offset.x}px, ${offset.y}px, 0)` }, onMove, reset };
}

export function finePointer() {
  return (
    typeof window !== "undefined" &&
    window.matchMedia("(hover: hover) and (pointer: fine)").matches &&
    !window.matchMedia("(prefers-reduced-motion: reduce)").matches
  );
}

/** Pointer tilt for cards, returns CSS custom props. */
export function useTilt<T extends HTMLElement = HTMLDivElement>(max = 7) {
  const ref = useRef<T | null>(null);
  const onMove = useCallback(
    (e: React.MouseEvent) => {
      const el = ref.current;
      if (!el || !finePointer()) return;
      const r = el.getBoundingClientRect();
      const px = (e.clientX - r.left) / r.width - 0.5;
      const py = (e.clientY - r.top) / r.height - 0.5;
      el.style.setProperty("--ry", `${px * max * 2}deg`);
      el.style.setProperty("--rx", `${-py * max * 2}deg`);
    },
    [max],
  );
  const onLeave = useCallback(() => {
    const el = ref.current;
    if (!el) return;
    el.style.setProperty("--ry", "0deg");
    el.style.setProperty("--rx", "0deg");
  }, []);
  return { ref, onMove, onLeave };
}

/** Window scroll progress 0 → 1 (rAF throttled). */
export function useScrollProgress() {
  const [p, setP] = useState(0);
  useEffect(() => {
    let raf = 0;
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const h = document.documentElement;
        const max = h.scrollHeight - h.clientHeight;
        setP(max > 0 ? Math.min(1, h.scrollTop / max) : 0);
      });
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);
  return p;
}

/** Live clock for a given IANA timezone. */
export function useClock(timeZone = "Asia/Kolkata") {
  const fmt = useMemo(
    () =>
      new Intl.DateTimeFormat("en-GB", {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        timeZone,
        hour12: false,
      }),
    [timeZone],
  );
  const [t, setT] = useState(() => fmt.format(new Date()));
  useEffect(() => {
    const id = window.setInterval(() => setT(fmt.format(new Date())), 1000);
    return () => window.clearInterval(id);
  }, [fmt]);
  return t;
}

/** Which section is currently in view (for nav highlighting). */
export function useActiveSection(ids: string[]) {
  const [active, setActive] = useState(ids[0]);
  useEffect(() => {
    const els = ids
      .map((id) => document.getElementById(id))
      .filter((el): el is HTMLElement => Boolean(el));
    if (!els.length || typeof IntersectionObserver === "undefined") return;
    const io = new IntersectionObserver(
      (entries) => {
        const vis = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (vis) setActive(vis.target.id);
      },
      { rootMargin: "-40% 0px -50% 0px", threshold: [0.01, 0.2, 0.6] },
    );
    els.forEach((el) => io.observe(el));
      return () => io.disconnect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ids.join("|")]);
  return active;
}
