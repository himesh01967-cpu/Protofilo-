export type Project = {
  id: string;
  index: string;
  title: string;
  client: string;
  category: "Product" | "Web" | "Motion" | "Systems";
  year: string;
  role: string;
  blurb: string;
  story: string[];
  tags: string[];
  scope: string[];
  stack: string[];
  metrics: { value: string; label: string }[];
  image: string;
  accent: string;
  site: string;
};

export const projects: Project[] = [
  {
    id: "nucleus",
    index: "01",
    title: "Nucleus",
    client: "Vertex Motors",
    category: "Motion",
    year: "2025",
    role: "Lead Creative Engineer",
    blurb:
      "A realtime 3D configurator that lets buyers paint, dress and light a car in the browser — no plugin, no wait.",
    story: [
      "Vertex had a WebGL toy built by three vendors and none of them shipped. I rebuilt it from the geometry up: Draco-compressed meshes, instanced paint layers, and a material system where the designer could tune clearcoat without touching code.",
      "The hard part was not the render — it was the 4G Android phone in Pune. So we built a device-tier pipeline that swaps mesh density and lighting rigs on the fly, keeping the interaction identical everywhere.",
    ],
    tags: ["WebGL", "Three.js", "Design Engineering"],
    scope: ["Configurator", "Shader system", "Perf rescue", "Docs"],
    stack: ["React", "Three.js", "GLSL", "R3F", "Zustand", "Cloudflare R2"],
    metrics: [
      { value: "1.9s", label: "TTI on 4G" },
      { value: "+38%", label: "Configure → quote" },
      { value: "58fps", label: "Median, mid-tier" },
    ],
    image:
      "https://images.pexels.com/photos/29450016/pexels-photo-29450016.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    accent: "#c9f24d",
    site: "https://example.com/nucleus",
  },
  {
    id: "paylane",
    index: "02",
    title: "Paylane",
    client: "Paylane Financial",
    category: "Product",
    year: "2025",
    role: "Design Systems Lead",
    blurb:
      "A treasury dashboard for people who stare at money all day: 240 screens, one grammar, zero surprises.",
    story: [
      "We replaced eleven forked UI kits with a single token pipeline — Figma variables compiled to CSS, shipped as a versioned package, enforced in CI. Designers stopped asking for permissions; engineers stopped writing one-off hexes.",
      "Every chart uses the same data-ink rules, and every dense table is keyboard-first. Support tickets about 'the numbers look different' dropped to zero in two quarters.",
    ],
    tags: ["Design System", "Data Viz", "A11y"],
    scope: ["Tokens", "Component kit", "Charts", "Governance"],
    stack: ["TypeScript", "Radix", "Style Dictionary", "Chart.js", "Vitest", "Storybook"],
    metrics: [
      { value: "240", label: "Screens shipped" },
      { value: "92%", label: "Less UI code" },
      { value: "AA+", label: "Audit score" },
    ],
    image:
      "https://images.pexels.com/photos/27141316/pexels-photo-27141316.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    accent: "#1f3bff",
    site: "https://example.com/paylane",
  },
  {
    id: "aroma",
    index: "03",
    title: "Aroma Studio",
    client: "Aroma D2C",
    category: "Web",
    year: "2024",
    role: "Front-of-store Engineer",
    blurb:
      "A skincare storefront that loads like a static page and checks out like a Fortune 500. Sold out in 11 hours.",
    story: [
      "Brand asked for 'editorial, but fast'. We shipped a fully static commerce layer — content on the edge, cart in a service worker, checkout hydrated only when the finger gets close.",
      "The product page has a texture-scrub interaction that took a week of tuning and is the single most-mentioned detail in customer interviews.",
    ],
    tags: ["Commerce", "Edge", "Art Direction"],
    scope: ["Storefront", "PDP interaction", "Checkout", "Analytics"],
    stack: ["Astro", "React islands", "Shopify Hydrogen", "Worklets", "Sanity"],
    metrics: [
      { value: "₹4.2cr", label: "Launch-day GMV" },
      { value: "0.6s", label: "LCP p75" },
      { value: "100", label: "Lighthouse" },
    ],
    image:
      "https://images.pexels.com/photos/34939699/pexels-photo-34939699.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    accent: "#ff4b26",
    site: "https://example.com/aroma",
  },
  {
    id: "kinetik",
    index: "04",
    title: "Kinetik",
    client: "Kinetik Athletics",
    category: "Motion",
    year: "2024",
    role: "Motion Director",
    blurb:
      "A motion identity for a running label — 60 seconds of film, 400 loops, one easing curve to rule them all.",
    story: [
      "We defined a brand by its physics instead of its palette: one acceleration profile used in film, app, retail screens and packaging AR. Designers got a motion bible with actual numbers in it.",
      "Everything ships as vector-driven WebGL so the same file works on a stadium LED wall and on a second-hand phone.",
    ],
    tags: ["Motion Identity", "Brand", "WebGL"],
    scope: ["Motion bible", "Loops", "Launch site", "Toolkit"],
    stack: ["After Effects", "GSAP", "Lottie", "WebGL", "Blender"],
    metrics: [
      { value: "400+", label: "Loops shipped" },
      { value: "3", label: "Motion awards" },
      { value: "12x", label: "Replay rate" },
    ],
    image:
      "https://images.pexels.com/photos/13026928/pexels-photo-13026928.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    accent: "#c9f24d",
    site: "https://example.com/kinetik",
  },
  {
    id: "vidyut",
    index: "05",
    title: "Vidyut",
    client: "State Learning Board",
    category: "Product",
    year: "2023",
    role: "Product Engineer",
    blurb:
      "Offline-first lessons for 2.1M students on devices with 1GB RAM and one bar of signal.",
    story: [
      "We built a sync engine that treats the network as an optional luxury: content packs, resumable downloads, conflict-free progress merge, and a UI that never shows a spinner.",
      "Accessibility was the brief, not the audit — screen-reader-first navigation and a colour system verified for four types of colour blindness.",
    ],
    tags: ["Offline-first", "A11y", "Scale"],
    scope: ["Architecture", "Sync engine", "UI system", "Field research"],
    stack: ["React", "IndexedDB", "Service Workers", "Django", "Postgres"],
    metrics: [
      { value: "2.1M", label: "Students" },
      { value: "87%", label: "Weekly retention" },
      { value: "3.4MB", label: "Offline pack" },
    ],
    image:
      "https://images.pexels.com/photos/16592498/pexels-photo-16592498.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    accent: "#1f3bff",
    site: "https://example.com/vidyut",
  },
  {
    id: "tracekit",
    index: "06",
    title: "Tracekit",
    client: "Open Source",
    category: "Systems",
    year: "2023",
    role: "Maintainer",
    blurb:
      "A lightweight trace explorer that fits in a browser tab. 9.4k stars and counting, zero telemetry.",
    story: [
      "Trace visualisation tools were either enterprise portals or CLI soup. Tracekit is a single canvas, a worker thread, and a query language you can learn in ten minutes.",
      "Virtualised spans handle 400k rows without dropping a frame, because I refuse to wait for a spinner to find a 12ms bottleneck.",
    ],
    tags: ["DevTools", "Canvas", "OSS"],
    scope: ["Product design", "Renderer", "Docs", "Community"],
    stack: ["TypeScript", "Canvas 2D", "Web Workers", "WASM", "Vite"],
    metrics: [
      { value: "9.4k", label: "GitHub stars" },
      { value: "400k", label: "Spans / frame" },
      { value: "0", label: "Telemetry calls" },
    ],
    image:
      "https://images.pexels.com/photos/5380603/pexels-photo-5380603.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    accent: "#ff4b26",
    site: "https://github.com",
  },
];

export const categories = ["All", "Product", "Web", "Motion", "Systems"] as const;

export const stats = [
  { value: 8, suffix: "", label: "Years shipping" },
  { value: 74, suffix: "", label: "Projects delivered" },
  { value: 31, suffix: "", label: "Clients & teams" },
  { value: 12, suffix: "", label: "Awards & mentions" },
];

export const capabilities = {
  labels: ["Interface", "Motion / WebGL", "Systems", "Perf", "Product", "Backend"],
  values: [96, 91, 88, 94, 82, 74],
};

export const toolbox = [
  "TypeScript",
  "React 19",
  "Next.js",
  "Three.js",
  "GLSL",
  "GSAP",
  "Tailwind v4",
  "Framer Motion",
  "Node",
  "tRPC",
  "Postgres",
  "Rust (a little)",
  "Figma",
  "Blender",
  "R3F",
  "Playwright",
];

export const services = [
  {
    num: "01",
    title: "Product Interface Engineering",
    line: "Design-quality builds that survive real users.",
    body: "I take a Figma file or a napkin and return a typed, tested, accessible product surface — component library included, so the next six screens cost a tenth of the effort.",
    deliverables: ["App UI build", "Component library", "Handoff docs", "Perf budget"],
    rate: "from ₹4.5L / month",
  },
  {
    num: "02",
    title: "Motion & 3D on the Web",
    line: "Interaction that people screenshot.",
    body: "Shader work, scroll choreography, product configurators, launch sites. Every effect ships with a reduced-motion path and a device-tier fallback so it never breaks on a £90 phone.",
    deliverables: ["WebGL scenes", "Scroll systems", "Motion bible", "Fallback tiers"],
    rate: "from ₹2.8L / project",
  },
  {
    num: "03",
    title: "Design Systems & Tokens",
    line: "One grammar for design, web and mobile.",
    body: "Token pipelines, governance, contribution models and the boring documentation that makes a system actually get used. I have migrated four teams without a single design review mutiny.",
    deliverables: ["Token pipeline", "Docs site", "CI checks", "Adoption plan"],
    rate: "from ₹6L / engagement",
  },
  {
    num: "04",
    title: "Performance Rescues",
    line: "Send me the slow page. That's the job.",
    body: "Two-week sprints: trace, cut bundles, fix waterfalls, cache, and get your Core Web Vitals out of the orange. Average result on last five engagements: 41% faster LCP.",
    deliverables: ["Full audit", "Fix sprint", "Monitoring", "Team training"],
    rate: "₹3.5L / 2-week sprint",
  },
];

export const experience = [
  {
    period: "2024 — Now",
    role: "Lead Creative Engineer",
    org: "Loom Studio",
    place: "Bengaluru / Remote",
    text: "Lead a six-person pod of designers and engineers on flagship product and brand work. Started the studio's motion practice and its open-source arm.",
    tags: ["Leadership", "Motion", "Client work"],
  },
  {
    period: "2022 — 2024",
    role: "Staff Frontend Engineer",
    org: "Paylane Financial",
    place: "Bengaluru",
    text: "Owned the design system used by 40+ engineers across web, iOS and Android. Cut median page load by 46% and shipped the treasury dashboard suite.",
    tags: ["Design systems", "Data viz", "Scale"],
  },
  {
    period: "2020 — 2022",
    role: "Product Designer → Engineer",
    org: "Zeno Labs",
    place: "Pune",
    text: "Started on design, kept the keyboard. Built the prototyping pipeline that let the team ship a customer-facing app every two weeks instead of every two quarters.",
    tags: ["Prototyping", "Research", "React"],
  },
  {
    period: "2018 — 2020",
    role: "Independent",
    org: "Freelance",
    place: "Anywhere with wifi",
    text: "48 sites, 9 brands, a lot of late nights. Learned to scope, price, and write the kind of CSS that a client can maintain without calling me.",
    tags: ["Freelance", "Brand", "Webflow"],
  },
];

export const recognition = [
  { year: "2025", title: "Awwwards — Site of the Day (×3)", org: "Awwwards" },
  { year: "2025", title: "CSS Design Awards — Best Innovation", org: "CSSDA" },
  { year: "2024", title: "Webby Nominee — Finance Dashboard", org: "The Webby Awards" },
  { year: "2024", title: "FWA of the Day — Kinetik", org: "The FWA" },
  { year: "2023", title: "Speaker — 'Interfaces that feel like nothing'", org: "React India" },
  { year: "2023", title: "Open-Source Grant — Tracekit", org: "NLnet style fund" },
];

export const testimonials = [
  {
    quote:
      "Aarav is the rare engineer who argues with the designer and is usually right. Our configurator went from a tech demo to our highest-converting page in six weeks.",
    name: "Rhea Kapoor",
    role: "VP Product, Vertex Motors",
    initials: "RK",
    color: "#1f3bff",
  },
  {
    quote:
      "He rebuilt our design system while the plane was still flying. Two years later, engineers still cite the docs in code review. That never happens.",
    name: "Daniel Osei",
    role: "Director of Engineering, Paylane",
    initials: "DO",
    color: "#c9f24d",
  },
  {
    quote:
      "We gave him a slow, ugly storefront and a hard deadline. He gave back a 0.6s LCP, a sold-out launch, and a team that knows how to keep it that way.",
    name: "Mitali Shah",
    role: "Founder, Aroma Studio",
    initials: "MS",
    color: "#ff4b26",
  },
  {
    quote:
      "Best motion brain I have worked with. He treats the easing curve like brand IP — and then documents it so the rest of us can copy it.",
    name: "Jonas Feld",
    role: "Creative Director, Kinetik",
    initials: "JF",
    color: "#12141a",
  },
];

export const labItems = [
  {
    title: "Elastic Nav",
    desc: "Nav that stretches like rubber when you drag it.",
    tag: "Interaction",
    emoji: "🪢",
  },
  {
    title: "SDF Text",
    desc: "Crisp display type at any zoom, from a single draw call.",
    tag: "Rendering",
    emoji: "🔤",
  },
  {
    title: "Sound on Scroll",
    desc: "A tiny synth that plays the page's velocity. Yes, it's optional.",
    tag: "Audio",
    emoji: "🎛️",
  },
];

export const socials = [
  { label: "GitHub", handle: "@aaravbuilds", href: "https://github.com" },
  { label: "Dribbble", handle: "@aarav", href: "https://dribbble.com" },
  { label: "X", handle: "@aaravbuilds", href: "https://x.com" },
  { label: "LinkedIn", handle: "in/aaravmehta", href: "https://linkedin.com" },
];

export const roles = [
  "creative developer",
  "interface engineer",
  "motion designer",
  "systems thinker",
];
