import { useEffect, useState } from "react";
import { cn } from "@/utils/cn";
import Cursor from "@/components/Cursor";
import Nav from "@/components/Nav";
import Hero from "@/components/Hero";
import Work from "@/components/Work";
import About from "@/components/About";
import Services from "@/components/Services";
import Experience from "@/components/Experience";
import Testimonials from "@/components/Testimonials";
import Lab from "@/components/Lab";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";
import Preloader from "@/components/Preloader";
import { useActiveSection } from "@/lib/hooks";

const RAIL = [
  { id: "work", label: "Selected work" },
  { id: "about", label: "About" },
  { id: "services", label: "Services" },
  { id: "path", label: "The path" },
  { id: "voices", label: "Voices" },
  { id: "lab", label: "Lab" },
  { id: "contact", label: "Contact" },
];

export default function App() {
  const active = useActiveSection(RAIL.map((r) => r.id));
  const [showTop, setShowTop] = useState(false);

  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > window.innerHeight * 1.2);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="relative min-h-screen bg-paper text-ink selection:bg-lime">
      <Preloader />
      <Cursor />
      <div className="grain" aria-hidden />
      <Nav />

      {/* right-hand section rail */}
      <nav
        aria-label="Section navigation"
        className="fixed right-4 top-1/2 z-[72] hidden -translate-y-1/2 flex-col items-end gap-3 mix-blend-difference xl:flex"
      >
        {RAIL.map((r) => (
          <button
            key={r.id}
            onClick={() =>
              document.getElementById(r.id)?.scrollIntoView({ behavior: "smooth", block: "start" })
            }
            className="group flex items-center gap-3"
            aria-current={active === r.id ? "true" : undefined}
          >
            <span className="label translate-x-2 text-[0.6rem] text-white opacity-0 transition-all duration-500 group-hover:translate-x-0 group-hover:opacity-100">
              {r.label}
            </span>
            <span
              className={cn(
                "block h-[2px] transition-all duration-500",
                active === r.id
                  ? "w-9 bg-white"
                  : "w-4 bg-white/40 group-hover:w-7 group-hover:bg-white",
              )}
            />
          </button>
        ))}
      </nav>

      <main>
        <Hero />
        <Work />
        <About />
        <Services />
        <Experience />
        <Testimonials />
        <Lab />
        <Contact />
      </main>
      <Footer />

      {/* floating top button (small screens, after scroll) */}
      <button
        onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        aria-label="Back to top"
        className={cn(
          "fixed bottom-5 right-5 z-[72] grid h-12 w-12 place-items-center rounded-full bg-lime text-ink shadow-[0_18px_40px_rgba(18,20,26,0.3)] transition-all duration-500 hover:bg-paper",
          showTop ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-6 opacity-0",
        )}
      >
        <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M12 20V5M5 12l7-7 7 7" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </button>
    </div>
  );
}
