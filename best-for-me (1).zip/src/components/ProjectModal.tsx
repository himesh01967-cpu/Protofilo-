import { useEffect, useRef } from "react";
import { ArrowRight, ArrowUpRight, X } from "lucide-react";
import { cn } from "@/utils/cn";
import { projects, type Project } from "@/lib/data";

type Props = {
  project: Project | null;
  onClose: () => void;
  onNavigate: (id: string) => void;
};

export default function ProjectModal({ project: incoming, onClose, onNavigate }: Props) {
  const open = Boolean(incoming);
  // keep the last case mounted so the panel doesn't empty out mid-slide
  const cache = useRef<Project | null>(null);
  if (incoming) cache.current = incoming;
  const project = incoming ?? cache.current;

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight" && project) {
        const i = projects.findIndex((p) => p.id === project.id);
        onNavigate(projects[(i + 1) % projects.length].id);
      }
      if (e.key === "ArrowLeft" && project) {
        const i = projects.findIndex((p) => p.id === project.id);
        onNavigate(projects[(i - 1 + projects.length) % projects.length].id);
      }
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose, onNavigate, project]);

  const idx = project ? projects.findIndex((p) => p.id === project.id) : -1;
  const next = projects[(idx + 1) % projects.length];

  return (
    <div
      className={cn(
        "fixed inset-0 z-[76] transition-opacity duration-500",
        open ? "pointer-events-auto opacity-100" : "pointer-events-none opacity-0",
      )}
      role="dialog"
      aria-modal="true"
      aria-label={project ? `${project.title} case study` : "Case study"}
    >
      <button
        className="absolute inset-0 h-full w-full cursor-pointer bg-ink/70 backdrop-blur-[3px]"
        onClick={onClose}
        aria-label="Close case study"
        tabIndex={open ? 0 : -1}
      />
      <article
        className={cn(
          "absolute inset-y-0 right-0 flex w-full max-w-[52rem] flex-col overflow-y-auto bg-paper transition-transform duration-700 ease-[cubic-bezier(0.16,1,0.3,1)]",
          open ? "translate-x-0" : "translate-x-full",
        )}
      >
        {project && (
          <>
            <div className="relative shrink-0 overflow-hidden border-b border-ink/12">
              <img
                src={project.image}
                alt={`${project.title} — ${project.blurb}`}
                className="h-[46vh] w-full object-cover md:h-[54vh]"
              />
              <div className="absolute inset-0 bg-linear-to-t from-ink/90 via-ink/25 to-ink/10" />
              <div className="absolute inset-x-0 top-0 flex items-start justify-between p-5">
                <span
                  className="rounded-full px-3 py-1.5 text-[0.66rem] font-semibold uppercase tracking-[0.16em] text-ink"
                  style={{ background: project.accent }}
                >
                  {project.category}
                </span>
                <button
                  onClick={onClose}
                  className="grid h-11 w-11 place-items-center rounded-full border border-paper/35 text-paper transition-colors hover:bg-paper hover:text-ink"
                  aria-label="Close"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
              <div className="absolute inset-x-0 bottom-0 p-6 sm:p-8">
                <p className="label mb-3 text-paper/70">
                  Case {project.index} · {project.client} · {project.year}
                </p>
                <h2 className="font-display text-[clamp(2.2rem,7vw,4.6rem)] uppercase leading-[0.85] text-paper">
                  {project.title}
                </h2>
              </div>
            </div>

            <div className="flex-1 px-5 py-8 sm:px-8 lg:px-10">
              <p className="font-serif text-[1.45rem] leading-[1.35] text-ink sm:text-[1.7rem]">
                {project.blurb}
              </p>

              <div className="mt-8 grid gap-4 sm:grid-cols-3">
                {project.metrics.map((m) => (
                  <div key={m.label} className="border border-ink/15 bg-paper-2 p-4">
                    <p className="tabular font-display text-[2rem] leading-none text-blue">
                      {m.value}
                    </p>
                    <p className="label mt-2 text-mute">{m.label}</p>
                  </div>
                ))}
              </div>

              <div className="mt-10 grid gap-10 sm:grid-cols-12">
                <div className="sm:col-span-8">
                  <h3 className="label mb-4 text-ink/50">The story</h3>
                  {project.story.map((s) => (
                    <p key={s.slice(0, 24)} className="mb-5 text-[0.98rem] leading-relaxed text-ink/80">
                      {s}
                    </p>
                  ))}
                  <a
                    href={project.site}
                    target="_blank"
                    rel="noreferrer"
                    className="group mt-2 inline-flex items-center gap-2 rounded-full bg-ink px-6 py-3 text-[0.74rem] font-semibold uppercase tracking-[0.16em] text-paper transition-colors hover:bg-blue"
                  >
                    Visit live project
                    <ArrowUpRight className="h-4 w-4 transition-transform duration-500 group-hover:translate-x-1 group-hover:-translate-y-1" />
                  </a>
                </div>
                <div className="sm:col-span-4">
                  <h3 className="label mb-4 text-ink/50">Scope</h3>
                  <ul className="mb-8 flex flex-col gap-2">
                    {project.scope.map((s) => (
                      <li key={s} className="flex items-center gap-2 text-sm text-ink/80">
                        <span className="h-1.5 w-1.5 rotate-45 bg-coral" />
                        {s}
                      </li>
                    ))}
                  </ul>
                  <h3 className="label mb-4 text-ink/50">Stack</h3>
                  <div className="flex flex-wrap gap-1.5">
                    {project.stack.map((t) => (
                      <span
                        key={t}
                        className="rounded-full border border-ink/20 px-2.5 py-1 text-[0.68rem] uppercase tracking-[0.1em] text-ink/65"
                      >
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <button
              onClick={() => onNavigate(next.id)}
              tabIndex={open ? 0 : -1}
              className="group relative flex shrink-0 items-center justify-between gap-6 border-t border-ink/12 bg-ink px-6 py-7 text-left text-paper transition-colors hover:bg-blue sm:px-10"
            >
              <span>
                <span className="label block text-paper/50">Next case</span>
                <span className="font-display text-[clamp(1.6rem,4.4vw,2.6rem)] uppercase leading-none">
                  {next.title}
                </span>
              </span>
              <ArrowRight className="h-9 w-9 shrink-0 transition-transform duration-500 group-hover:translate-x-2" />
            </button>
          </>
        )}
      </article>
    </div>
  );
}
