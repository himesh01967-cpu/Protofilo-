import { cn } from "@/utils/cn";

type Props = {
  items: string[];
  speed?: number;
  reverse?: boolean;
  className?: string;
  separator?: string;
  size?: "sm" | "lg";
};

/** Seamless infinite ticker (duplicated track, paused on hover). */
export default function Marquee({
  items,
  speed = 34,
  reverse = false,
  className,
  separator = "✷",
  size = "lg",
}: Props) {
  const row = [...items, ...items];
  return (
    <div
      className={cn("marquee-wrap overflow-hidden", className)}
      style={{ ["--speed" as string]: `${speed}s` }}
    >
      <div className={cn("marquee-track flex w-max items-center", reverse && "reverse")}>
        {row.map((t, i) => (
          <span
            key={i}
            className={cn(
              "flex shrink-0 items-center gap-6 pr-6",
              size === "lg"
                ? "font-display text-[clamp(1.5rem,4.4vw,3.4rem)] uppercase leading-none"
                : "label gap-3 pr-3",
            )}
          >
            <span>{t}</span>
            <span
              className={cn(
                "opacity-45",
                size === "lg" ? "text-[clamp(1rem,2.2vw,1.6rem)]" : "text-[0.7rem]",
              )}
            >
              {separator}
            </span>
          </span>
        ))}
      </div>
    </div>
  );
}
