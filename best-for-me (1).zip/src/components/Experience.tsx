import { useEffect, useRef, useState } from "react";
import { experience, recognition } from "@/lib/data";
import { Reveal, Section, SectionHead } from "./UI";

export default function Experience() {
  const wrap = useRef<HTMLDivElement | null>(null);
  const [fill, setFill] = useState(0);

  useEffect(() => {
    let raf = 0;
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const el = wrap.current;
        if (!el) return;
        const r = el.getBoundingClientRect();
        const anchor = window.innerHeight * 0.55;
        const p = (anchor - r.top) / r.height;
        setFill(Math.max(0, Math.min(1, p)));
      });
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <Section id="path" className="bg-paper">
      <SectionHead
        index="04"
        kicker="The path"
        title={
          <>
            Eight years,
            <br />
            four chapters
          </>
        }
        intro={
          <p>
            Studios, fintech, government scale, and a long freelance apprenticeship in shipping
            things people actually open. The through-line: I kept getting pulled closer to the
            product decision.
          </p>
        }
      />

      <div ref={wrap} className="relative mt-16 grid gap-10 lg:grid-cols-12">
        {/* rail */}
        <div className="absolute left-[0.55rem] top-2 hidden h-[calc(100%-3rem)] w-px bg-ink/12 lg:block">
          <div
            className="w-full origin-top bg-blue transition-transform duration-150 ease-out"
            style={{ height: "100%", transform: `scaleY(${fill})` }}
          />
        </div>

        <ol className="flex flex-col gap-10 lg:col-span-8 lg:gap-14">
          {experience.map((e, i) => (
            <Reveal as="li" key={e.role + e.period} delay={i * 80} className="relative lg:pl-14">
              <span className="absolute left-0 top-2 hidden h-[1.1rem] w-[1.1rem] -translate-x-[0.15rem] rotate-45 border-2 border-ink bg-paper lg:block">
                <span
                  className="absolute inset-[3px] bg-blue"
                  style={{ opacity: fill > i / experience.length ? 1 : 0, transition: "opacity .5s" }}
                />
              </span>
              <p className="label mb-2 text-coral">{e.period}</p>
              <h3 className="font-display text-[clamp(1.7rem,4.2vw,2.9rem)] uppercase leading-[0.92]">
                {e.role}
              </h3>
              <p className="mt-2 text-[0.95rem] font-semibold text-ink/70">
                {e.org} <span className="font-normal text-mute">· {e.place}</span>
              </p>
              <p className="mt-4 max-w-2xl text-[1rem] leading-relaxed text-ink/75">{e.text}</p>
              <div className="mt-4 flex flex-wrap gap-2">
                {e.tags.map((t) => (
                  <span
                    key={t}
                    className="rounded-full bg-paper-2 px-3 py-1 text-[0.68rem] uppercase tracking-[0.12em] text-ink/60"
                  >
                    {t}
                  </span>
                ))}
              </div>
            </Reveal>
          ))}
        </ol>

        <div className="lg:col-span-4">
          <div className="lg:sticky lg:top-28">
            <div className="border border-ink/15 bg-ink p-6 text-paper">
              <p className="label mb-6 text-lime">Recognition</p>
              <ul className="flex flex-col">
                {recognition.map((r) => (
                  <li
                    key={r.title}
                    className="group border-b border-paper/10 py-3.5 last:border-0"
                  >
                    <p className="tabular text-[0.68rem] tracking-[0.18em] text-paper/45">
                      {r.year}
                    </p>
                    <p className="mt-1 text-[0.92rem] font-medium leading-snug transition-colors group-hover:text-lime">
                      {r.title}
                    </p>
                    <p className="text-[0.76rem] text-paper/45">{r.org}</p>
                  </li>
                ))}
              </ul>
            </div>
            <div className="mt-5 border border-ink/15 bg-paper-2 p-6">
              <p className="label mb-3 text-mute">Also true</p>
              <p className="text-sm leading-relaxed text-ink/75">
                B.E. Computer Science, Pune (2018). Teaching assistant for two decades of design
                students each winter — the fastest way to keep your own instincts sharp.
              </p>
            </div>
          </div>
        </div>
      </div>
    </Section>
  );
}
