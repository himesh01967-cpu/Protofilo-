import { useMemo } from "react";
import {
  Chart as ChartJS,
  Filler,
  LineElement,
  PointElement,
  RadialLinearScale,
  Tooltip,
  type ChartOptions,
} from "chart.js";
import { Radar } from "react-chartjs-2";
import { capabilities, toolbox } from "@/lib/data";
import { Chip, Reveal, Section, SectionHead } from "./UI";

ChartJS.register(Filler, LineElement, PointElement, RadialLinearScale, Tooltip);

const principles = [
  {
    k: "Motion is meaning",
    v: "An animation should explain where you came from and where you are going. If it only decorates, I delete it.",
  },
  {
    k: "Performance is design",
    v: "A 3-second load is a design decision, not an engineering failure. Budgets get written down before pixels move.",
  },
  {
    k: "One system, many surfaces",
    v: "Web, kiosk, email, native — same tokens, same grammar, no second source of truth.",
  },
  {
    k: "Ship, then polish",
    v: "I would rather hand you a working thing on Friday than a perfect diagram on the 20th.",
  },
];

export default function About() {
  const data = useMemo(
    () => ({
      labels: capabilities.labels.map((l) => l.toUpperCase()),
      datasets: [
        {
          label: "Depth",
          data: capabilities.values,
          backgroundColor: "rgba(201,242,77,0.22)",
          borderColor: "#c9f24d",
          borderWidth: 2,
          pointBackgroundColor: "#ff4b26",
          pointBorderColor: "#ff4b26",
          pointRadius: 4,
          pointHoverRadius: 7,
        },
      ],
    }),
    [],
  );

  const options = useMemo<ChartOptions<"radar">>(
    () => ({
      responsive: true,
      maintainAspectRatio: false,
      animation: { duration: 1400, easing: "easeOutQuart" },
      plugins: {
        tooltip: {
          backgroundColor: "#ece9e1",
          titleColor: "#12141a",
          bodyColor: "#1f3bff",
          titleFont: { family: "Space Grotesk", size: 11 },
          bodyFont: { family: "Anton", size: 18 },
          padding: 10,
          displayColors: false,
          callbacks: { label: (c) => `${c.formattedValue} / 100` },
        },
        legend: { display: false },
      },
      scales: {
        r: {
          min: 0,
          max: 100,
          angleLines: { color: "rgba(236,233,225,0.14)" },
          grid: { color: "rgba(236,233,225,0.14)", circular: true },
          ticks: { display: false, stepSize: 25 },
          pointLabels: {
            color: "rgba(236,233,225,0.62)",
            font: { family: "Space Grotesk", size: 10, weight: 600 },
          },
        },
      },
    }),
    [],
  );

  return (
    <Section id="about" dark>
      <div className="rule-col-dark pointer-events-none absolute inset-0 opacity-70" />
      <div className="relative">
        <SectionHead
          dark
          index="02"
          kicker="About / Operating manual"
          title={
            <>
              Design brain,
              <br />
              engineer hands
            </>
          }
          intro={
            <p>
              I started as a designer who kept opening devtools. Eight years later that is the whole
              job: I live in the seam between the Figma file and the production bundle, and I make
              sure nothing gets lost in it.
            </p>
          }
        />

        <div className="mt-16 grid gap-12 lg:grid-cols-12">
          {/* sticky capability panel */}
          <div className="lg:col-span-5">
            <div className="lg:sticky lg:top-28">
              <Reveal>
                <div className="border border-paper/15 bg-ink-2 p-5 sm:p-7">
                  <div className="mb-5 flex items-center justify-between">
                    <p className="label text-lime">Capability map</p>
                    <p className="label text-paper/40">Self-assessed · 2026</p>
                  </div>
                  <div className="relative h-[19rem] sm:h-[22rem]">
                    <Radar data={data} options={options} />
                  </div>
                  <ul className="mt-6 grid grid-cols-2 gap-x-5 gap-y-2 border-t border-paper/10 pt-5">
                    {capabilities.labels.map((l, i) => (
                      <li key={l} className="flex items-center justify-between gap-3 text-sm">
                        <span className="text-paper/65">{l}</span>
                        <span className="tabular font-display text-lg text-paper">
                          {capabilities.values[i]}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              </Reveal>

              <Reveal delay={120}>
                <div className="mt-5 flex items-center gap-4 border border-paper/15 bg-linear-to-br from-blue/25 to-transparent p-5">
                  <p className="font-display text-[2.6rem] leading-none text-lime">100</p>
                  <p className="text-sm text-paper/70">
                    Highest Lighthouse performance score I have shipped — 22 times out of 24
                    projects.
                  </p>
                </div>
              </Reveal>
            </div>
          </div>

          {/* manifesto */}
          <div className="lg:col-span-7">
            <Reveal>
              <p className="font-serif text-[clamp(1.7rem,3.6vw,2.7rem)] leading-[1.18] text-paper">
                &ldquo;A good interface feels like nothing at all. It is the elevator that arrives
                before you press the button, the receipt that adds up, the animation that tells you
                where you were. My job is to remove everything between a person and the thing they
                came to do — then leave a little delight as a tip.&rdquo;
              </p>
            </Reveal>

            <div className="mt-10 grid gap-6 sm:grid-cols-2">
              <Reveal delay={80}>
                <p className="text-[0.98rem] leading-relaxed text-paper/75">
                  I work best embedded with a small team: one designer, one PM, a lot of trust. I
                  write the CSS myself, I argue about the type scale, and I document what I build
                  so the team is not hostage to me after launch.
                </p>
              </Reveal>
              <Reveal delay={160}>
                <p className="text-[0.98rem] leading-relaxed text-paper/75">
                  Off the clock: film photography (Portra 400, always), cricket nets, restoring a
                  1994 Royal Enfield that I am not allowed to ride yet, and a running note titled
                  &ldquo;things I would fix about apps&rdquo; with 400 entries.
                </p>
              </Reveal>
            </div>

            <div className="mt-12">
              <p className="label mb-5 text-paper/45">Principles I keep breaking &amp; repairing</p>
              <ul className="grid gap-px overflow-hidden border border-paper/15 bg-paper/15 sm:grid-cols-2">
                {principles.map((p, i) => (
                  <li key={p.k} className="group bg-ink px-5 py-6 transition-colors hover:bg-ink-2">
                    <p className="tabular mb-3 font-display text-sm text-coral">
                      {String(i + 1).padStart(2, "0")}
                    </p>
                    <h3 className="font-display text-xl uppercase text-paper transition-colors group-hover:text-lime">
                      {p.k}
                    </h3>
                    <p className="mt-2 text-sm leading-relaxed text-paper/65">{p.v}</p>
                  </li>
                ))}
              </ul>
            </div>

            <div className="mt-12">
              <p className="label mb-4 text-paper/45">Toolbox</p>
              <div className="flex flex-wrap gap-2">
                {toolbox.map((t, i) => (
                  <Reveal key={t} delay={i * 25} as="span">
                    <Chip dark>{t}</Chip>
                  </Reveal>
                ))}
              </div>
            </div>

            <Reveal>
              <div className="mt-12 flex flex-wrap items-end justify-between gap-6 border-t border-paper/15 pt-6">
                <p className="font-serif text-3xl italic text-lime">— Aarav</p>
                <p className="text-sm text-paper/55">
                  ex–Paylane · lead at Loom Studio · currently taking two projects per quarter
                </p>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </Section>
  );
}
