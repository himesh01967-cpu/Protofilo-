import { useEffect, useRef, useState } from "react";
import { ArrowUpRight } from "lucide-react";
import { cn } from "@/utils/cn";
import { categories, projects, type Project } from "@/lib/data";
import { finePointer } from "@/lib/hooks";
import { Reveal, Section, SectionHead } from "./UI";
import ProjectModal from "./ProjectModal";

export default function Work() {
  const [filter, setFilter] = useState<(typeof categories)[number]>("All");
  const [openId, setOpenId] = useState<string | null>(null);
  const [hover, setHover] = useState<Project | null>(null);
  const follower = useRef<HTMLDivElement | null>(null);

  const list = filter === "All" ? projects : projects.filter((p) => p.category === filter);
  const current = projects.find((p) => p.id === openId) ?? null;

  useEffect(() => {
    if (!finePointer()) return;
    let raf = 0;
    const target = { x: 0, y: 0 };
    const pos = { x: 0, y: 0 };
    const move = (e: PointerEvent) => {
      target.x = e.clientX;
      target.y = e.clientY;
    };
    const loop = () => {
      pos.x += (target.x - pos.x) * 0.13;
      pos.y += (target.y - pos.y) * 0.13;
      if (follower.current)
        follower.current.style.transform = `translate3d(${pos.x}px, ${pos.y}px, 0) translate(-50%,-50%)`;
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    window.addEventListener("pointermove", move, { passive: true });
    return () => {
      window.removeEventListener("pointermove", move);
      cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <Section id="work" className="bg-paper">
      <div className="dotgrid pointer-events-none absolute inset-0 opacity-[0.35]" />
      <div className="relative">
        <SectionHead
          index="01"
          kicker="Selected work"
          title={
            <>
              Six things
              <br />
              I&apos;m proud of
            </>
          }
          intro={
            <>
              <p>
                Every project below went from brief to production with me in the loop — often as
                the only engineer between a design file and a deploy button.
              </p>
              <p className="text-mute">
                Hover a row for a peek. Click it for the full case study: constraints, decisions,
                numbers.
              </p>
            </>
          }
        />

        {/* filters */}
        <div className="mt-12 flex flex-wrap items-center gap-2 border-y border-ink/12 py-4">
          <span className="label mr-3 text-mute">Filter</span>
          {categories.map((c) => {
            const count =
              c === "All" ? projects.length : projects.filter((p) => p.category === c).length;
            const active = filter === c;
            return (
              <button
                key={c}
                onClick={() => setFilter(c)}
                className={cn(
                  "group inline-flex items-center gap-2 rounded-full border px-4 py-2 text-[0.72rem] font-semibold uppercase tracking-[0.13em] transition-all duration-300",
                  active
                    ? "border-ink bg-ink text-paper"
                    : "border-ink/20 text-ink/60 hover:border-ink hover:text-ink",
                )}
              >
                {c}
                <span className={cn("tabular text-[0.62rem]", active ? "text-lime" : "text-mute")}>
                  {String(count).padStart(2, "0")}
                </span>
              </button>
            );
          })}
          <span className="label ml-auto hidden text-mute lg:block">
            {String(list.length).padStart(2, "0")} shown / 06 total
          </span>
        </div>

        {/* rows */}
        <ul className="relative" onPointerLeave={() => setHover(null)}>
          {list.map((p, i) => (
            <Reveal as="li" key={p.id} delay={i * 70}>
              <button
                onClick={() => setOpenId(p.id)}
                onMouseEnter={() => setHover(p)}
                onFocus={() => setHover(p)}
                data-cursor="expand"
                data-cursor-label="open"
                className={cn(
                  "group grid w-full grid-cols-1 items-center gap-5 border-b border-ink/12 py-7 text-left transition-colors duration-500",
                  "sm:grid-cols-12 sm:gap-6",
                  "hover:bg-ink hover:px-5 hover:text-paper",
                )}
              >
                <span className="label tabular text-blue sm:col-span-1 group-hover:text-lime">
                  {p.index}
                </span>
                <div className="sm:col-span-5">
                  <h3 className="font-display text-[clamp(1.7rem,4.6vw,3.1rem)] uppercase leading-[0.9] transition-transform duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:translate-x-2">
                    {p.title}
                  </h3>
                  <p className="mt-1.5 text-[0.82rem] text-mute transition-colors group-hover:text-paper/60">
                    {p.client} · {p.role}
                  </p>
                </div>
                <div className="flex flex-wrap gap-1.5 sm:col-span-4">
                  {p.tags.map((t) => (
                    <span
                      key={t}
                      className="rounded-full border border-ink/15 px-2.5 py-1 text-[0.64rem] font-medium uppercase tracking-[0.12em] text-ink/60 transition-colors group-hover:border-paper/25 group-hover:text-paper/70"
                    >
                      {t}
                    </span>
                  ))}
                </div>
                <span className="label tabular text-mute sm:col-span-1 group-hover:text-paper/70">
                  {p.year}
                </span>
                <span className="hidden h-11 w-11 shrink-0 place-items-center rounded-full border border-ink/20 text-ink transition-all duration-500 group-hover:rotate-45 group-hover:border-lime group-hover:bg-lime group-hover:text-ink sm:col-span-1 sm:grid">
                  <ArrowUpRight className="h-4 w-4 -rotate-45 transition-transform duration-500" />
                </span>

                {/* mobile preview */}
                <div className="relative -mx-5 aspect-[16/9] overflow-hidden sm:hidden">
                  <img
                    src={p.image}
                    alt={`${p.title} preview`}
                    loading="lazy"
                    className="h-full w-full object-cover"
                  />
                </div>
              </button>
            </Reveal>
          ))}
        </ul>

        {/* cursor-following peek */}
        <div
          ref={follower}
          aria-hidden
          className={cn(
            "pointer-events-none fixed left-0 top-0 z-40 hidden h-[19rem] w-[27rem] overflow-hidden rounded-[4px] shadow-[0_30px_70px_rgba(18,20,26,0.35)] transition-[opacity,scale] duration-500 lg:block",
            hover ? "opacity-100 scale-100" : "opacity-0 scale-90",
          )}
        >
          <div
            className="relative h-full w-full border-[3px] bg-ink"
            style={{ borderColor: hover?.accent }}
          >
            {list.map((p) => (
              <img
                key={p.id}
                src={p.image}
                alt=""
                aria-hidden
                className={cn(
                  "absolute inset-0 h-full w-full object-cover transition-opacity duration-300",
                  hover?.id === p.id ? "opacity-100" : "opacity-0",
                )}
              />
            ))}
            <div className="absolute inset-0 bg-linear-to-t from-ink/85 to-transparent" />
            <div className="absolute inset-x-0 bottom-0 flex items-center justify-between p-4">
              <p className="font-display text-lg uppercase text-paper">{hover?.title}</p>
              <p className="label text-lime">{hover?.category}</p>
            </div>
          </div>
        </div>

        <Reveal className="mt-10 flex flex-wrap items-center justify-between gap-4 border border-ink/15 bg-paper-2 p-5">
          <p className="max-w-xl text-sm text-ink/70">
            Five more case studies (enterprise, gov-tech, two startups that didn&apos;t make it)
            live in the private deck — happy to walk through them on a call.
          </p>
          <a
            href="#contact"
            className="group inline-flex items-center gap-2 text-[0.76rem] font-semibold uppercase tracking-[0.16em] text-blue"
          >
            Request full deck
            <ArrowUpRight className="h-4 w-4 transition-transform duration-500 group-hover:translate-x-1 group-hover:-translate-y-1" />
          </a>
        </Reveal>
      </div>

      <ProjectModal project={current} onClose={() => setOpenId(null)} onNavigate={setOpenId} />
    </Section>
  );
}
