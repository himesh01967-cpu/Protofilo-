import type { ReactNode } from "react";
import { ArrowUpRight } from "lucide-react";
import { cn } from "@/utils/cn";
import { useMagnetic, useReveal } from "@/lib/hooks";

type RevealProps = {
  children: ReactNode;
  className?: string;
  delay?: number;
  variant?: "up" | "mask" | "side";
  as?: "div" | "li" | "section" | "article" | "span";
};

/** Scroll-triggered entrance. */
export function Reveal({
  children,
  className,
  delay = 0,
  variant = "up",
  as: Tag = "div",
}: RevealProps) {
  const { ref, cls } = useReveal<HTMLDivElement>();
  const base = variant === "mask" ? "mask-reveal" : variant === "side" ? "slide-x" : "reveal";
  return (
    <Tag
      ref={ref as never}
      className={cn(base, cls, className)}
      style={{ ["--d" as string]: `${delay}ms` }}
    >
      {children}
    </Tag>
  );
}

export function SectionHead({
  index,
  kicker,
  title,
  intro,
  right,
  dark = false,
}: {
  index: string;
  kicker: string;
  title: ReactNode;
  intro?: ReactNode;
  right?: ReactNode;
  dark?: boolean;
}) {
  return (
    <div className="relative">
      <div
        className={cn(
          "flex items-center gap-4 border-b pb-4",
          dark ? "border-paper/15 text-paper/60" : "border-ink/15 text-mute",
        )}
      >
        <span className="label tabular">{index}</span>
        <span className={cn("label", dark && "text-lime")}>{kicker}</span>
        <span
          className={cn(
            "ml-auto hidden h-2 w-2 rotate-45 sm:block",
            dark ? "bg-lime" : "bg-coral",
          )}
        />
      </div>
      <div className="mt-8 grid gap-8 lg:grid-cols-12 lg:items-end">
        <Reveal className="lg:col-span-7">
          <h2 className={cn("display-lg", dark ? "text-paper" : "text-ink")}>{title}</h2>
        </Reveal>
        <Reveal delay={120} className="lg:col-span-5">
          <div
            className={cn(
              "flex flex-col gap-5 text-[0.98rem] leading-relaxed",
              dark ? "text-paper/70" : "text-ink/70",
            )}
          >
            {intro}
            {right}
          </div>
        </Reveal>
      </div>
    </div>
  );
}

/** Magnetic pill CTA with an arrow that slides on hover. */
export function MagneticLink({
  children,
  href,
  onClick,
  variant = "solid",
  className,
  label,
}: {
  children: ReactNode;
  href?: string;
  onClick?: () => void;
  variant?: "solid" | "ghost" | "lime";
  className?: string;
  label?: string;
}) {
  const { ref, style, onMove, reset } = useMagnetic<HTMLAnchorElement>(0.28);
  const palette =
    variant === "solid"
      ? "bg-blue text-paper hover:bg-ink"
      : variant === "lime"
        ? "bg-lime text-ink hover:bg-paper"
        : "border border-current text-ink hover:bg-ink hover:text-paper";

  const Comp = (
    <a
      ref={ref}
      href={href}
      onClick={onClick}
      onMouseMove={onMove}
      onMouseLeave={reset}
      style={style}
      data-cursor={label ? "expand" : undefined}
      data-cursor-label={label}
      className={cn(
        "group relative inline-flex items-center gap-3 rounded-full px-7 py-4 text-[0.82rem] font-semibold uppercase tracking-[0.14em] transition-colors duration-300 will-change-transform",
        palette,
        className,
      )}
    >
      <span>{children}</span>
      <ArrowUpRight className="h-4 w-4 transition-transform duration-500 ease-out group-hover:translate-x-1 group-hover:-translate-y-1" />
    </a>
  );
  return Comp;
}

export function Chip({
  children,
  className,
  dark = false,
}: {
  children: ReactNode;
  className?: string;
  dark?: boolean;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-3 py-1.5 text-[0.68rem] font-medium uppercase tracking-[0.13em] transition-colors duration-300",
        dark
          ? "border-paper/20 text-paper/75 hover:border-lime hover:text-lime"
          : "border-ink/20 text-ink/70 hover:border-blue hover:text-blue",
        className,
      )}
    >
      {children}
    </span>
  );
}

export function Section({
  id,
  children,
  className,
  dark = false,
}: {
  id: string;
  children: ReactNode;
  className?: string;
  dark?: boolean;
}) {
  return (
    <section
      id={id}
      className={cn(
        "relative scroll-mt-20",
        dark ? "bg-ink text-paper" : "",
        "px-5 py-24 sm:px-8 md:py-32 lg:px-12",
        className,
      )}
    >
      <div className="mx-auto w-full max-w-[86rem]">{children}</div>
    </section>
  );
}
