import { useEffect, useRef, useState } from "react";
import { finePointer } from "@/lib/hooks";

/** Lagging ring + dot cursor. Only mounts on fine-pointer devices. */
export default function Cursor() {
  const [on, setOn] = useState(false);
  const ring = useRef<HTMLDivElement | null>(null);
  const dot = useRef<HTMLDivElement | null>(null);
  const label = useRef<HTMLSpanElement | null>(null);
  const state = useRef({ x: 0, y: 0, rx: 0, ry: 0, scale: 1, label: "" });

  useEffect(() => {
    if (!finePointer()) return;
    setOn(true);
    document.documentElement.classList.add("custom-cursor");
    const s = state.current;

    const move = (e: PointerEvent) => {
      s.x = e.clientX;
      s.y = e.clientY;
      const el = (e.target as HTMLElement)?.closest?.(
        "a,button,[data-cursor],input,textarea,select",
      ) as HTMLElement | null;
      const interactive = Boolean(el);
      s.scale = el?.dataset.cursor === "expand" ? 2.5 : interactive ? 1.9 : 1;
      const next = el?.dataset.cursorLabel ?? "";
      if (label.current && next !== s.label) {
        s.label = next;
        label.current.textContent = next;
      }
      if (dot.current)
        dot.current.style.transform = `translate3d(${e.clientX}px, ${e.clientY}px, 0) translate(-50%,-50%)`;
    };

    let raf = 0;
    const loop = () => {
      s.rx += (s.x - s.rx) * 0.16;
      s.ry += (s.y - s.ry) * 0.16;
      if (ring.current) {
        ring.current.style.transform = `translate3d(${s.rx}px, ${s.ry}px, 0) translate(-50%,-50%) scale(${s.scale})`;
        ring.current.style.opacity = s.label ? "1" : "0.85";
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    window.addEventListener("pointermove", move, { passive: true });
    return () => {
      window.removeEventListener("pointermove", move);
      cancelAnimationFrame(raf);
      document.documentElement.classList.remove("custom-cursor");
    };
  }, []);

  if (!on) return null;
  return (
    <div className="pointer-events-none fixed inset-0 z-[80] hidden lg:block mix-blend-difference">
      <div
        ref={ring}
        className="absolute left-0 top-0 grid h-11 w-11 place-items-center rounded-full border border-paper/70 transition-transform duration-200 ease-out"
      >
        <span
          ref={label}
          className="label text-[7px] tracking-[0.18em] text-paper opacity-0 transition-opacity duration-150"
        />
      </div>
      <div ref={dot} className="absolute left-0 top-0 h-1.5 w-1.5 rounded-full bg-lime" />
    </div>
  );
}
