import { useEffect, useRef, useState } from "react";
import { cn } from "@/utils/cn";

/** 1.4s intro: counter, growing rule, then a two-panel curtain lift. */
export default function Preloader() {
  const [pct, setPct] = useState(0);
  const [done, setDone] = useState(false);
  const [gone, setGone] = useState(false);
  const started = useRef(false);

  useEffect(() => {
    if (started.current) return;
    started.current = true;

    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) {
      setGone(true);
      return;
    }

    const dur = 1150;
    const t0 = performance.now();
    let raf = 0;
    const tick = (now: number) => {
      const p = Math.min(1, (now - t0) / dur);
      setPct(Math.round(100 * (1 - Math.pow(1 - p, 2))));
      if (p < 1) raf = requestAnimationFrame(tick);
      else setDone(true);
    };
    raf = requestAnimationFrame(tick);

    document.body.style.overflow = "hidden";
    const release = window.setTimeout(() => {
      document.body.style.overflow = "";
    }, dur + 620);
    const unmount = window.setTimeout(() => setGone(true), dur + 700);

    return () => {
      cancelAnimationFrame(raf);
      window.clearTimeout(release);
      window.clearTimeout(unmount);
      document.body.style.overflow = "";
    };
  }, []);

  if (gone) return null;

  return (
    <div
      aria-hidden
      className="fixed inset-0 z-[90] flex flex-col justify-end bg-ink text-paper"
      style={{
        transition: "transform .8s cubic-bezier(0.76,0,0.24,1)",
        transform: done ? "translateY(-101%)" : "none",
      }}
    >
      <div className="dotgrid pointer-events-none absolute inset-0 opacity-[0.12]" />

      <div className="relative mx-auto w-full max-w-[86rem] px-5 pb-10 sm:px-8 lg:px-12">
        <div className="mb-8 flex items-end justify-between gap-6">
          <div>
            <p className="label mb-4 text-lime">Aarav Mehta · Portfolio Vol. 04</p>
            <p className="font-display text-[clamp(2rem,7vw,5rem)] uppercase leading-[0.86]">
              Loading
              <br />
              <span className="stroke-text text-paper">the good stuff</span>
            </p>
          </div>
          <p className="tabular font-display text-[clamp(2.4rem,9vw,7rem)] leading-none text-lime">
            {String(pct).padStart(3, "0")}
          </p>
        </div>
        <div className="h-[3px] w-full bg-paper/15">
          <div
            className="h-full bg-lime"
            style={{ width: `${pct}%`, transition: "width .18s linear" }}
          />
        </div>
        <p
          className={cn(
            "label mt-5 flex flex-wrap justify-between gap-3 text-paper/45 transition-opacity duration-300",
            done ? "opacity-0" : "opacity-100",
          )}
        >
          <span>Fetching type · warming shaders · trimming bytes</span>
          <span>Bengaluru, IN</span>
        </p>
      </div>
    </div>
  );
}
