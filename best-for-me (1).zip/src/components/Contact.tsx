import { useState } from "react";
import { ArrowUpRight, Check, FileDown, Loader2, Sparkles } from "lucide-react";
import { cn } from "@/utils/cn";
import { useClock } from "@/lib/hooks";
import { MagneticLink } from "./UI";
import { experience, projects, recognition, stats, toolbox } from "@/lib/data";

/** Builds a plain-text résumé from the same data the site renders. */
function ResumeButton() {
  const [ok, setOk] = useState(false);

  const download = () => {
    const line = "=".repeat(58);
    const body = [
      "AARAV MEHTA — CREATIVE DEVELOPER & INTERFACE ENGINEER",
      "Bengaluru, IN · hello@aaravmehta.dev · aaravmehta.dev",
      "",
      line,
      "PROFILE",
      line,
      "Eight years designing and engineering fast, tactile web products: product UI,",
      "motion/WebGL, design systems and performance rescues. Ships typed, tested,",
      "accessible code and documents it so teams can keep it.",
      "",
      line,
      `BY THE NUMBERS — ${stats.map((s) => `${s.value} ${s.label.toLowerCase()}`).join(" · ")}`,
      line,
      "",
      line,
      "EXPERIENCE",
      line,
      ...experience.flatMap((e) => [
        `${e.period} · ${e.role} — ${e.org} (${e.place})`,
        `   ${e.text}`,
        `   Focus: ${e.tags.join(", ")}`,
        "",
      ]),
      line,
      "SELECTED WORK",
      line,
      ...projects.map((p) =>
        `${p.year} · ${p.title} (${p.client}) — ${p.category}. ${p.blurb}\n   Results: ${p.metrics
          .map((m) => `${m.value} ${m.label}`)
          .join(" · ")}`,
      ),
      "",
      line,
      "TOOLBOX",
      line,
      toolbox.join(" · "),
      "",
      line,
      "RECOGNITION",
      line,
      ...recognition.map((r) => `${r.year} · ${r.title} — ${r.org}`),
      "",
      "Generated from aaravmehta.dev — " + new Date().toISOString().slice(0, 10),
    ].join("\n");

    const url = URL.createObjectURL(new Blob([body], { type: "text/plain;charset=utf-8" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = "Aarav-Mehta-Resume.txt";
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    setOk(true);
    window.setTimeout(() => setOk(false), 2400);
  };

  return (
    <button
      onClick={download}
      className="group inline-flex items-center gap-2 rounded-full border border-paper/25 px-6 py-3.5 text-[0.76rem] font-semibold uppercase tracking-[0.16em] text-paper/75 transition-colors hover:border-lime hover:text-lime"
    >
      <FileDown className="h-4 w-4 transition-transform duration-500 group-hover:translate-y-0.5" />
      {ok ? "Saved to downloads" : "Download résumé"}
    </button>
  );
}

const budgets = ["₹1–3L", "₹3–8L", "₹8–20L", "₹20L+"];
const kinds = ["Product build", "Motion / 3D", "Design system", "Perf rescue", "Advisory"];

type Errors = Partial<Record<"name" | "email" | "message", string>>;

export default function Contact() {
  const time = useClock();
  const [form, setForm] = useState({
    name: "",
    email: "",
    company: "",
    kind: kinds[0],
    budget: budgets[1],
    message: "",
  });
  const [errors, setErrors] = useState<Errors>({});
  const [state, setState] = useState<"idle" | "sending" | "sent">("idle");

  const set = (k: keyof typeof form) => (v: string) => {
    setForm((f) => ({ ...f, [k]: v }));
    setErrors((e) => ({ ...e, [k]: undefined }));
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const next: Errors = {};
    if (form.name.trim().length < 2) next.name = "Tell me who you are";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(form.email)) next.email = "Needs a real email";
    if (form.message.trim().length < 24)
      next.message = `${Math.max(0, 24 - form.message.trim().length)} more characters of context, please`;
    setErrors(next);
    if (Object.keys(next).length) return;
    setState("sending");
    window.setTimeout(() => setState("sent"), 1300);
  };

  return (
    <section
      id="contact"
      className="relative scroll-mt-20 overflow-hidden bg-ink px-5 py-24 text-paper sm:px-8 md:py-32 lg:px-12"
    >
      <div className="rule-col-dark pointer-events-none absolute inset-0 opacity-60" />
      <div
        className="pointer-events-none absolute -right-40 top-10 h-[34rem] w-[34rem] rounded-full opacity-40 blur-[110px]"
        style={{ background: "radial-gradient(circle, rgba(31,59,255,.85), transparent 65%)" }}
      />
      <div className="relative mx-auto w-full max-w-[86rem]">
        <div className="flex flex-wrap items-center gap-4 border-b border-paper/15 pb-5">
          <span className="label tabular text-paper/45">07</span>
          <span className="label text-lime">Contact</span>
          <span className="label ml-auto flex items-center gap-2 text-paper/70">
            <span className="h-1.5 w-1.5 rounded-full bg-lime blink" />
            Two slots left · starts {time} IST
          </span>
        </div>

        <div className="mt-12 grid gap-12 lg:grid-cols-12">
          {/* pitch */}
          <div className="lg:col-span-5">
            <h2 className="display-lg text-paper">
              Let&apos;s build
              <br />
              something
              <br />
              <span className="text-lime">ridiculous</span>
            </h2>
            <p className="mt-7 max-w-md text-[1.02rem] leading-relaxed text-paper/70">
              Send the ugly draft: the Figma link, the Lighthouse report, the half-formed idea. I
              reply within one working day with a view on scope, a rough number, and — if I&apos;m
              not the right fit — someone who is.
            </p>

            <ul className="mt-10 flex flex-col">
              {[
                { k: "Response time", v: "Under 24h, Mon–Fri" },
                { k: "Working hours", v: "IST 10:00–19:00, overlap to 21:00 CET" },
                { k: "Engagements", v: "3 weeks – 6 months, contract via ToR" },
                { k: "Not for me", v: "Crypto casinos, deadline-only pitches" },
              ].map((r) => (
                <li
                  key={r.k}
                  className="flex flex-wrap items-baseline justify-between gap-3 border-b border-paper/10 py-3.5"
                >
                  <span className="label text-paper/45">{r.k}</span>
                  <span className="text-sm text-paper/85">{r.v}</span>
                </li>
              ))}
            </ul>

            <div className="mt-10 flex flex-wrap items-center gap-3">
              <MagneticLink href="mailto:hello@aaravmehta.dev" variant="lime">
                hello@aaravmehta.dev
              </MagneticLink>
              <ResumeButton />
              <a
                href="#lab"
                className="group inline-flex items-center gap-2 text-[0.76rem] font-semibold uppercase tracking-[0.16em] text-paper/60 transition-colors hover:text-lime"
              >
                Play with the lab first
                <ArrowUpRight className="h-4 w-4 transition-transform duration-500 group-hover:translate-x-1 group-hover:-translate-y-1" />
              </a>
            </div>
          </div>

          {/* form */}
          <div className="lg:col-span-7">
            <div className="relative border border-paper/15 bg-ink-2 p-5 sm:p-8">
              {state === "sent" ? (
                <div className="flex min-h-[26rem] flex-col items-start justify-center">
                  <span className="grid h-14 w-14 place-items-center rounded-full bg-lime text-ink">
                    <Check className="h-7 w-7" />
                  </span>
                  <h3 className="mt-6 font-display text-[clamp(1.9rem,4.4vw,3.1rem)] uppercase leading-[0.92]">
                    Brief received,
                    <br />
                    {form.name.split(" ")[0] || "friend"}
                  </h3>
                  <p className="mt-4 max-w-md text-[0.98rem] leading-relaxed text-paper/70">
                    A confirmation is on its way to{" "}
                    <span className="text-lime">{form.email}</span>. I&apos;ll come back with scope,
                    a date and a number for a <span className="text-paper">{form.kind.toLowerCase()}</span>{" "}
                    in the {form.budget} band.
                  </p>
                  <div className="mt-8 flex flex-wrap gap-3">
                    <button
                      onClick={() => setState("idle")}
                      className="rounded-full border border-paper/25 px-5 py-2.5 text-[0.72rem] font-semibold uppercase tracking-[0.14em] transition-colors hover:bg-paper hover:text-ink"
                    >
                      Send another
                    </button>
                    <span className="inline-flex items-center gap-2 rounded-full bg-lime/15 px-4 py-2.5 text-[0.72rem] uppercase tracking-[0.14em] text-lime">
                      <Sparkles className="h-3.5 w-3.5" /> Ref: AM-{Date.now().toString().slice(-5)}
                    </span>
                  </div>
                </div>
              ) : (
                <form onSubmit={submit} noValidate className="grid gap-6 sm:grid-cols-2">
                  <Field
                    label="Your name"
                    value={form.name}
                    onChange={set("name")}
                    error={errors.name}
                    placeholder="Rhea Kapoor"
                  />
                  <Field
                    label="Email"
                    type="email"
                    value={form.email}
                    onChange={set("email")}
                    error={errors.email}
                    placeholder="you@company.com"
                  />
                  <Field
                    label="Company (optional)"
                    value={form.company}
                    onChange={set("company")}
                    placeholder="Vertex Motors"
                  />
                  <label className="block">
                    <span className="label mb-2 block text-paper/45">What do you need</span>
                    <select
                      value={form.kind}
                      onChange={(e) => set("kind")(e.target.value)}
                      className="w-full appearance-none border-b border-paper/25 bg-transparent py-2.5 text-[0.95rem] text-paper outline-none transition-colors focus:border-lime"
                    >
                      {kinds.map((k) => (
                        <option key={k} className="bg-ink text-paper">
                          {k}
                        </option>
                      ))}
                    </select>
                  </label>

                  <div className="sm:col-span-2">
                    <span className="label mb-3 block text-paper/45">Budget band</span>
                    <div className="flex flex-wrap gap-2">
                      {budgets.map((b) => (
                        <button
                          type="button"
                          key={b}
                          onClick={() => set("budget")(b)}
                          className={cn(
                            "rounded-full border px-4 py-2 text-[0.76rem] font-semibold tracking-[0.08em] transition-all duration-300",
                            form.budget === b
                              ? "border-lime bg-lime text-ink"
                              : "border-paper/25 text-paper/65 hover:border-paper",
                          )}
                        >
                          {b}
                        </button>
                      ))}
                    </div>
                  </div>

                  <label className="block sm:col-span-2">
                    <span className="label mb-2 flex items-center justify-between text-paper/45">
                      The brief
                      <span className="tabular">
                        {form.message.trim().length} / 24 min
                      </span>
                    </span>
                    <textarea
                      rows={5}
                      value={form.message}
                      onChange={(e) => set("message")(e.target.value)}
                      placeholder="What's broken, what's the deadline, who else is involved…"
                      className={cn(
                        "w-full resize-none border-b bg-transparent py-2.5 text-[0.95rem] leading-relaxed text-paper outline-none transition-colors placeholder:text-paper/30",
                        errors.message ? "border-coral focus:border-coral" : "border-paper/25 focus:border-lime",
                      )}
                    />
                    {errors.message && (
                      <span className="mt-1.5 block text-[0.74rem] text-coral">{errors.message}</span>
                    )}
                  </label>

                  <div className="flex flex-wrap items-center justify-between gap-4 sm:col-span-2">
                    <p className="max-w-[22rem] text-[0.72rem] leading-relaxed text-paper/40">
                      This demo form never leaves your browser — no backend is attached, nothing is
                      stored or sent anywhere.
                    </p>
                    <button
                      type="submit"
                      disabled={state === "sending"}
                      className="group inline-flex items-center gap-3 rounded-full bg-lime px-7 py-3.5 text-[0.78rem] font-bold uppercase tracking-[0.16em] text-ink transition-all duration-300 hover:bg-paper disabled:opacity-70"
                    >
                      {state === "sending" ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <ArrowUpRight className="h-4 w-4 transition-transform duration-500 group-hover:translate-x-1 group-hover:-translate-y-1" />
                      )}
                      {state === "sending" ? "Sending" : "Send the brief"}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Field({
  label,
  value,
  onChange,
  error,
  placeholder,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  error?: string;
  placeholder?: string;
  type?: string;
}) {
  return (
    <label className="block">
      <span className="label mb-2 block text-paper/45">{label}</span>
      <input
        type={type}
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className={cn(
          "w-full border-b bg-transparent py-2.5 text-[0.95rem] text-paper outline-none transition-colors placeholder:text-paper/30",
          error ? "border-coral focus:border-coral" : "border-paper/25 focus:border-lime",
        )}
      />
      {error && <span className="mt-1.5 block text-[0.74rem] text-coral">{error}</span>}
    </label>
  );
}
