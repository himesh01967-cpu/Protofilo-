import { useCallback, useEffect, useRef, useState } from "react";
import { ArrowLeft, ArrowRight, Quote } from "lucide-react";
import { cn } from "@/utils/cn";
import { testimonials } from "@/lib/data";
import { Section } from "./UI";

const clients = [
  "Vertex Motors",
  "Paylane",
  "Aroma",
  "Kinetik",
  "Zeno Labs",
  "State Learning Board",
];

export default function Testimonials() {
  const [i, setI] = useState(0);
  const [dir, setDir] = useState(1);
  const timer = useRef<number | null>(null);
  const n = testimonials.length;

  const goTo = useCallback(
    (idx: number) => {
      setDir(idx > i ? 1 : -1);
      setI(((idx % n) + n) % n);
    },
    [i, n],
  );

  const step = useCallback((d: 1 | -1) => {
    setDir(d);
    setI((v) => (v + d + n) % n);
  }, [n]);

  useEffect(() => {
    timer.current = window.setInterval(() => step(1), 6500);
    return () => {
      if (timer.current) window.clearInterval(timer.current);
    };
  }, [step, i]);

  const t = testimonials[i];

  return (
    <Section id="voices" dark className="overflow-hidden">
      <div className="relative">
        <div className="flex flex-wrap items-end justify-between gap-6 border-b border-paper/15 pb-6">
          <div className="flex items-center gap-4">
            <span className="label tabular text-paper/45">05</span>
            <span className="label text-lime">Voices</span>
          </div>
          <p className="label text-paper/45">
            {String(i + 1).padStart(2, "0")} / {String(n).padStart(2, "0")}
          </p>
        </div>

        <Quote className="mt-10 h-12 w-12 text-coral" />

        <div className="mt-6 min-h-[16rem] sm:min-h-[13rem]">
          <blockquote
            key={i}
            className="font-serif text-[clamp(1.6rem,4.3vw,3rem)] leading-[1.16] text-paper"
            style={{
              animation: `quoteIn .7s cubic-bezier(0.16,1,0.3,1) both`,
              ["--from" as string]: `${dir * 26}px`,
            }}
          >
            {t.quote}
          </blockquote>

          <div key={`m-${i}`} className="mt-8 flex items-center gap-4">
            <span
              className="grid h-12 w-12 shrink-0 place-items-center rounded-full font-display text-sm text-ink"
              style={{ background: t.color === "#12141a" ? "#ece9e1" : t.color }}
            >
              {t.initials}
            </span>
            <span>
              <span className="block text-[0.95rem] font-semibold text-paper">{t.name}</span>
              <span className="block text-[0.82rem] text-paper/55">{t.role}</span>
            </span>
          </div>
        </div>

        <div className="mt-10 flex items-center gap-4">
          <button
            onClick={() => step(-1)}
            aria-label="Previous testimonial"
            className="grid h-12 w-12 place-items-center rounded-full border border-paper/25 text-paper transition-colors hover:border-lime hover:bg-lime hover:text-ink"
          >
            <ArrowLeft className="h-4.5 w-4.5" />
          </button>
          <button
            onClick={() => step(1)}
            aria-label="Next testimonial"
            className="grid h-12 w-12 place-items-center rounded-full border border-paper/25 text-paper transition-colors hover:border-lime hover:bg-lime hover:text-ink"
          >
            <ArrowRight className="h-4.5 w-4.5" />
          </button>
          <div className="ml-3 flex flex-1 gap-1.5">
            {testimonials.map((_, idx) => (
              <button
                key={idx}
                onClick={() => goTo(idx)}
                aria-label={`Testimonial ${idx + 1}`}
                className={cn(
                  "h-[3px] flex-1 max-w-24 transition-colors duration-500",
                  idx === i ? "bg-lime" : "bg-paper/20 hover:bg-paper/45",
                )}
              />
            ))}
          </div>
        </div>

        {/* client ticker */}
        <div className="mt-16 border-t border-paper/15 pt-8">
          <p className="label mb-5 text-paper/45">Trusted by teams at</p>
          <div className="marquee-wrap overflow-hidden">
            <div className="marquee-track flex w-max items-center gap-14" style={{ ["--speed" as string]: "38s" }}>
              {[...clients, ...clients].map((c, idx) => (
                <span
                  key={idx}
                  className="font-display text-[clamp(1.3rem,3.2vw,2.4rem)] uppercase text-paper/35 transition-colors hover:text-paper"
                >
                  {c}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes quoteIn {
          from { opacity: 0; transform: translateX(var(--from, 26px)); }
          to { opacity: 1; transform: none; }
        }
      `}</style>
    </Section>
  );
}
