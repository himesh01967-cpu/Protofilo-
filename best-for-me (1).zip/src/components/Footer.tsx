import { useEffect, useState } from "react";
import { ArrowUp, Heart } from "lucide-react";
import Marquee from "./Marquee";
import { socials } from "@/lib/data";
import { useClock } from "@/lib/hooks";

export default function Footer() {
  const time = useClock();
  const [vp, setVp] = useState({ w: 0, h: 0 });

  useEffect(() => {
    const on = () => setVp({ w: window.innerWidth, h: window.innerHeight });
    on();
    window.addEventListener("resize", on);
    return () => window.removeEventListener("resize", on);
  }, []);

  const nav = [
    { label: "Work", id: "work" },
    { label: "About", id: "about" },
    { label: "Services", id: "services" },
    { label: "Path", id: "path" },
    { label: "Voices", id: "voices" },
    { label: "Lab", id: "lab" },
  ];

  return (
    <footer className="relative overflow-hidden bg-ink-2 pt-14 text-paper">
      <div className="border-y border-paper/12 bg-lime py-2.5 text-ink">
        <Marquee
          items={["Available for select work", "Bengaluru → anywhere", "Let's build something ridiculous"]}
          speed={26}
          separator="✷"
        />
      </div>

      <div className="mx-auto w-full max-w-[86rem] px-5 py-16 sm:px-8 lg:px-12">
        <div className="grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <p className="font-serif text-[clamp(1.5rem,3.2vw,2.2rem)] leading-[1.2] text-paper/85">
              Currently leading the motion practice at Loom Studio, and taking two independent
              engagements a quarter.
            </p>
            <a
              href="mailto:hello@aaravmehta.dev"
              className="group mt-8 inline-flex items-center gap-3 font-display text-[clamp(1.6rem,4.4vw,2.6rem)] uppercase leading-none text-lime"
            >
              hello@aaravmehta.dev
              <span className="h-2 w-2 rounded-full bg-lime transition-transform duration-500 group-hover:scale-[2.4]" />
            </a>
          </div>

          <div className="lg:col-span-3">
            <p className="label mb-5 text-paper/40">Index</p>
            <ul className="grid grid-cols-2 gap-y-2.5">
              {nav.map((l) => (
                <li key={l.id}>
                  <button
                    onClick={() =>
                      document.getElementById(l.id)?.scrollIntoView({ behavior: "smooth" })
                    }
                    className="link-underline text-sm text-paper/75 hover:text-paper"
                  >
                    {l.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div className="lg:col-span-4">
            <p className="label mb-5 text-paper/40">Elsewhere</p>
            <ul className="grid grid-cols-2 gap-y-2.5">
              {socials.map((s) => (
                <li key={s.label}>
                  <a
                    href={s.href}
                    target="_blank"
                    rel="noreferrer"
                    className="link-underline text-sm text-paper/75 hover:text-lime"
                  >
                    {s.label}
                  </a>
                </li>
              ))}
            </ul>
            <p className="label mt-8 text-paper/40">Colophon</p>
            <p className="mt-3 text-[0.82rem] leading-relaxed text-paper/60">
              Typeset in Anton, Instrument Serif &amp; Space Grotesk. Built with React 19, Vite,
              Tailwind v4, Chart.js and Lucide icons. No template, no page builder, no AI slop.
            </p>
          </div>
        </div>

        <div className="mt-16 flex flex-col gap-6 border-t border-paper/12 pt-6 sm:flex-row sm:items-center">
          <p className="tabular text-[0.72rem] uppercase tracking-[0.14em] text-paper/45">
            © 2026 Aarav Mehta · Bengaluru {time} IST · viewport {vp.w}×{vp.h}
          </p>
          <p className="ml-auto flex items-center gap-1.5 text-[0.72rem] uppercase tracking-[0.14em] text-paper/45">
            Made with <Heart className="h-3.5 w-3.5 text-coral" /> and too much filter coffee
          </p>
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            className="group grid h-11 w-11 place-items-center rounded-full border border-paper/25 transition-colors hover:border-lime hover:bg-lime hover:text-ink"
            aria-label="Back to top"
          >
            <ArrowUp className="h-4 w-4 transition-transform duration-500 group-hover:-translate-y-1" />
          </button>
        </div>
      </div>
    </footer>
  );
}
