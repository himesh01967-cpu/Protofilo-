import { useEffect, useState } from "react";
import { ArrowDown, Copy, Check } from "lucide-react";
import Marquee from "./Marquee";
import { roles, stats } from "@/lib/data";
import { MagneticLink } from "./UI";
import { finePointer, useCountUp, useReveal, useScramble, useTilt } from "@/lib/hooks";

const PORTRAIT =
  "https://images.pexels.com/photos/10493916/pexels-photo-10493916.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800";
const EMAIL = "hello@aaravmehta.dev";

export default function Hero() {
  const role = useScramble(roles, 2400);
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  useEffect(() => {
    const onScroll = () => {
      const el = document.getElementById("hero-bg");
      if (el && finePointer())
        el.style.transform = `translate3d(0, ${Math.min(window.scrollY, 900) * 0.12}px, 0)`;
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header id="top" className="relative overflow-hidden border-b border-ink/12 bg-paper">
      {/* layered ambient background */}
      <div id="hero-bg" className="pointer-events-none absolute inset-0 will-change-transform">
        <div className="rule-col absolute inset-0" />
        <div className="absolute -left-[6vw] top-[46%] hidden w-[112%] select-none font-display text-[23vw] leading-none text-ink/[0.045] md:block">
          AARAV MEHTA
        </div>
        <div className="absolute -right-24 -top-24 h-[30rem] w-[30rem] rounded-full bg-lime/25 blur-[90px]" />
        <div className="absolute bottom-[-10rem] left-[18%] h-[26rem] w-[26rem] rounded-full bg-blue/10 blur-[100px]" />
      </div>

      <div className="relative mx-auto w-full max-w-[86rem] px-5 pt-24 pb-0 sm:px-8 lg:px-12 lg:pt-28">
        {/* top meta strip */}
        <div className="flex flex-wrap items-center gap-x-8 gap-y-3 border-b border-ink/12 pb-5">
          <span className="label text-blue">Portfolio · Vol. 04</span>
          <span className="label text-mute">Bengaluru, IN · 12.97°N</span>
          <span className="label text-mute">Practising since 2018</span>
          <span className="label ml-auto hidden items-center gap-2 text-ink/70 md:inline-flex">
            <ArrowDown className="h-3.5 w-3.5 animate-bounce" /> Scroll to decode
          </span>
        </div>

        <div className="grid gap-x-10 gap-y-12 pt-10 lg:grid-cols-12 lg:pt-14">
          {/* nameplate */}
          <div className="lg:col-span-8">
            <p className="label mb-6 text-ink/55">
              Aarav Mehta — creative developer &amp; interface engineer
            </p>
            <h1 className="display-xl text-ink">
              {["Interfaces", "that feel", "alive"].map((line, i) => (
                <span key={line} className="block overflow-hidden py-[0.03em]">
                  <span
                    className={
                      i === 2
                        ? "block stroke-text text-ink transition-transform duration-[900ms] ease-[cubic-bezier(0.16,1,0.3,1)]"
                        : "block transition-transform duration-[900ms] ease-[cubic-bezier(0.16,1,0.3,1)]"
                    }
                    style={{
                      transform: mounted ? "none" : "translateY(105%)",
                      transitionDelay: `${140 + i * 130}ms`,
                    }}
                  >
                    {i === 2 ? (
                      <>
                        {line}
                        <span className="text-coral not-italic" style={{ WebkitTextStroke: "0", color: "#ff4b26" }}>
                          .
                        </span>
                      </>
                    ) : (
                      line
                    )}
                  </span>
                </span>
              ))}
            </h1>

            <div className="mt-8 flex flex-col gap-8 sm:flex-row sm:items-start">
              <p className="max-w-xl text-[1.02rem] leading-relaxed text-ink/75 sm:text-[1.1rem]">
                I build the fast, tactile kind of product —{" "}
                <em className="font-serif text-[1.22em] not-italic text-ink">
                  WebGL launch sites, design systems and dashboards
                </em>{" "}
                that hold 60fps on a two-year-old Android. Eight years, 74 shipped projects, one
                rule: if it doesn't feel good in the hand, it doesn't ship.
              </p>
              <div className="shrink-0 border-l border-ink/15 pl-5">
                <p className="label text-mute">Currently</p>
                <p className="tabular mt-2 font-display text-xl text-blue uppercase">
                  {role}
                  <span className="ml-1 inline-block h-[0.9em] w-[0.5ch] translate-y-[0.08em] bg-blue blink" />
                </p>
              </div>
            </div>

            <div className="mt-10 flex flex-wrap items-center gap-4">
              <MagneticLink href="#work" variant="solid" label="view">
                Selected work
              </MagneticLink>
              <MagneticLink href="#contact" variant="ghost">
                Book a 20-min call
              </MagneticLink>
              <CopyEmail />
            </div>
          </div>

          {/* portrait card */}
          <div className="lg:col-span-4">
            <PortraitCard />
          </div>
        </div>

        {/* stats strip */}
        <div className="mt-16 grid grid-cols-2 border-t border-ink/12 sm:grid-cols-4">
          {stats.map((s, i) => (
            <StatCell key={s.label} {...s} className={i < 3 ? "sm:border-r border-ink/12" : ""} />
          ))}
        </div>
      </div>

      <div className="relative mt-12 border-y border-ink/12 bg-lime py-3">
        <Marquee
          items={[
            "webgl",
            "react 19",
            "design systems",
            "motion direction",
            "performance",
            "typescript",
            "accessibility",
          ]}
          speed={30}
          separator="·"
          className="text-ink"
        />
      </div>
    </header>
  );
}

function PortraitCard() {
  const { ref, onMove, onLeave } = useTilt<HTMLDivElement>(6);
  return (
    <div
      ref={ref}
      onMouseMove={onMove}
      onMouseLeave={onLeave}
      data-cursor="expand"
      data-cursor-label="hello"
      className="tilt group relative"
    >
      <div className="relative overflow-hidden border-[6px] border-ink bg-ink shadow-cut">
        <div className="relative aspect-[4/5] overflow-hidden">
          <img
            src={PORTRAIT}
            alt="Aarav Mehta, creative developer, in his studio"
            loading="eager"
            className="kenburns h-full w-full object-cover grayscale-[0.35] transition-[filter] duration-700 group-hover:grayscale-0"
          />
          <div className="absolute inset-0 bg-linear-to-t from-ink/80 via-transparent to-transparent" />
          <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-3 p-4">
            <p className="label text-paper">Studio, Bengaluru</p>
            <p className="label text-lime">2026</p>
          </div>
        </div>
      </div>

      {/* rotating seal */}
      <div className="spin-slow absolute -left-10 -top-10 hidden h-28 w-28 place-items-center rounded-full bg-blue text-paper sm:grid">
        <svg viewBox="0 0 100 100" className="absolute inset-0 h-full w-full">
          <defs>
            <path id="seal" d="M50,50 m-36,0 a36,36 0 1,1 72,0 a36,36 0 1,1 -72,0" />
          </defs>
          <text className="font-body" fontSize="10.5" letterSpacing="1.6" fill="currentColor">
            <textPath href="#seal">
              AVAILABLE FOR SELECT PROJECTS · Q3 2026 ·
            </textPath>
          </text>
        </svg>
        <span className="h-2 w-2 rounded-full bg-lime" />
      </div>

      <div className="absolute -bottom-6 -right-4 floaty rounded-full border border-ink/15 bg-paper px-4 py-2 text-[0.72rem] font-semibold uppercase tracking-[0.12em] shadow-[0_10px_30px_rgba(18,20,26,0.14)]">
        60fps or it doesn&apos;t ship
      </div>
    </div>
  );
}

function StatCell({
  value,
  label,
  className,
}: {
  value: number;
  label: string;
  className?: string;
}) {
  const { ref, shown } = useReveal<HTMLDivElement>({ threshold: 0.4 });
  const n = useCountUp(value, shown, 1600);
  return (
    <div ref={ref} className={`border-ink/12 py-6 sm:border-r sm:pl-0 ${className ?? ""}`}>
      <p className="tabular font-display text-[clamp(2.4rem,6vw,3.8rem)] leading-none">
        {String(n).padStart(2, "0")}
      </p>
      <p className="label mt-2 text-mute">{label}</p>
    </div>
  );
}

function CopyEmail() {
  const [done, setDone] = useState(false);
  return (
    <button
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(EMAIL);
        } catch {
          /* clipboard blocked — still show feedback */
        }
        setDone(true);
        window.setTimeout(() => setDone(false), 2200);
      }}
      className="group inline-flex items-center gap-2 text-[0.78rem] font-medium tracking-tight text-ink/60 transition-colors hover:text-ink"
    >
      {done ? <Check className="h-4 w-4 text-blue" /> : <Copy className="h-4 w-4" />}
      {done ? "Copied — go on, say hi" : EMAIL}
    </button>
  );
}
