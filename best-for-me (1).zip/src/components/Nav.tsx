import { useEffect, useMemo, useState } from "react";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { cn } from "@/utils/cn";
import { useActiveSection, useClock, useScrollProgress } from "@/lib/hooks";
import { socials } from "@/lib/data";

const links = [
  { id: "work", label: "Work", n: "01" },
  { id: "about", label: "About", n: "02" },
  { id: "services", label: "Services", n: "03" },
  { id: "path", label: "Path", n: "04" },
  { id: "voices", label: "Voices", n: "05" },
  { id: "lab", label: "Lab", n: "06" },
  { id: "contact", label: "Contact", n: "07" },
];

export default function Nav() {
  const progress = useScrollProgress();
  const active = useActiveSection(useMemoIds());
  const [open, setOpen] = useState(false);
  const [solid, setSolid] = useState(false);
  const time = useClock();

  useEffect(() => {
    const onScroll = () => setSolid(window.scrollY > 80);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open]);

  const go = (id: string) => {
    setOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <>
      {/* scroll progress */}
      <div className="fixed inset-x-0 top-0 z-[75] h-[3px] bg-ink/10">
        <div
          className="h-full origin-left bg-blue transition-transform duration-150 ease-out"
          style={{ transform: `scaleX(${progress})` }}
        />
      </div>

      <header
        className={cn(
          "fixed inset-x-0 top-[3px] z-[74] transition-all duration-500",
          solid
            ? "border-b border-ink/12 bg-paper/92 py-2.5 backdrop-blur-[6px]"
            : "border-b border-transparent py-4",
        )}
      >
        <nav className="mx-auto flex w-full max-w-[86rem] items-center gap-6 px-5 sm:px-8 lg:px-12">
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            className="group flex items-center gap-3"
            aria-label="Back to top"
          >
            <span className="grid h-9 w-9 place-items-center rounded-[10px] bg-lime font-display text-[0.9rem] leading-none text-ink transition-transform duration-500 group-hover:rotate-[-8deg]">
              AM
            </span>
            <span className="hidden sm:block">
              <span className="block text-[0.82rem] font-semibold uppercase tracking-[0.16em] leading-none">
                Aarav Mehta
              </span>
              <span className="label mt-1 block text-mute">Creative developer</span>
            </span>
          </button>

          <ul className="ml-auto hidden items-center gap-7 xl:flex">
            {links.slice(0, 6).map((l) => (
              <li key={l.id}>
                <button
                  onClick={() => go(l.id)}
                  className={cn(
                    "link-underline text-[0.78rem] font-semibold uppercase tracking-[0.14em] transition-colors",
                    active === l.id ? "text-blue" : "text-ink/65 hover:text-ink",
                  )}
                >
                  {l.label}
                </button>
              </li>
            ))}
          </ul>

          <div className="ml-auto flex items-center gap-3 xl:ml-0">
            <span className="hidden items-center gap-2 rounded-full border border-ink/15 px-3 py-1.5 md:inline-flex">
              <span className="h-1.5 w-1.5 rounded-full bg-coral blink" />
              <span className="label text-ink/70">Open for Q3</span>
            </span>
            <button
              onClick={() => go("contact")}
              className="hidden rounded-full bg-ink px-5 py-2.5 text-[0.72rem] font-semibold uppercase tracking-[0.16em] text-paper transition-colors hover:bg-blue lg:block"
            >
              Start a project
            </button>
            <button
              onClick={() => setOpen((v) => !v)}
              aria-label={open ? "Close menu" : "Open menu"}
              className="grid h-10 w-10 place-items-center rounded-full border border-ink/20 transition-colors hover:border-ink hover:bg-ink hover:text-paper"
            >
              {open ? <X className="h-4.5 w-4.5" /> : <Menu className="h-4.5 w-4.5" />}
            </button>
          </div>
        </nav>
      </header>

      {/* overlay menu */}
      <div
        className={cn(
          "fixed inset-0 z-[73] bg-ink text-paper transition-[clip-path,opacity] duration-700 ease-[cubic-bezier(0.16,1,0.3,1)]",
          open ? "pointer-events-auto opacity-100 [clip-path:circle(150%_at_100%_0)]" : "pointer-events-none opacity-0 [clip-path:circle(0%_at_100%_0)]",
        )}
        aria-hidden={!open}
      >
        <div className="dotgrid pointer-events-none absolute inset-0 opacity-[0.14]" />
        <div className="relative mx-auto flex h-full w-full max-w-[86rem] flex-col justify-center gap-10 px-5 pt-24 pb-10 sm:px-8 lg:px-12">
          <ul className="flex flex-col">
            {links.map((l, i) => (
              <li
                key={l.id}
                className="border-b border-paper/10"
                style={{
                  transitionDelay: `${open ? 160 + i * 55 : 0}ms`,
                  opacity: open ? 1 : 0,
                  transform: open ? "none" : "translateY(24px)",
                  transition: "opacity .5s ease, transform .6s cubic-bezier(0.16,1,0.3,1)",
                }}
              >
                <button
                  onClick={() => go(l.id)}
                  className="group flex w-full items-baseline gap-5 py-2.5 text-left"
                >
                  <span className="label tabular text-lime">{l.n}</span>
                  <span className="display-lg text-[clamp(1.9rem,7vw,4.4rem)] transition-all duration-500 group-hover:translate-x-3 group-hover:text-lime">
                    {l.label}
                  </span>
                  <ArrowUpRight className="ml-auto hidden h-7 w-7 shrink-0 text-paper/40 transition-all duration-500 group-hover:text-lime sm:block" />
                </button>
              </li>
            ))}
          </ul>

          <div className="grid gap-8 border-t border-paper/10 pt-8 sm:grid-cols-3">
            <div>
              <p className="label mb-3 text-paper/45">Local time · IST</p>
              <p className="tabular font-display text-2xl">{time}</p>
            </div>
            <div>
              <p className="label mb-3 text-paper/45">Elsewhere</p>
              <ul className="flex flex-col gap-1.5">
                {socials.map((s) => (
                  <li key={s.label}>
                    <a
                      href={s.href}
                      target="_blank"
                      rel="noreferrer"
                      className="link-underline text-sm text-paper/80 hover:text-lime"
                    >
                      {s.label} <span className="text-paper/40">{s.handle}</span>
                    </a>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="label mb-3 text-paper/45">Now playing</p>
              <p className="text-sm leading-relaxed text-paper/80">
                A WebGPU particle field, a mechanical keyboard switch test, and too much filter
                coffee.
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

function useMemoIds() {
  return useMemo(() => links.map((l) => l.id), []);
}
