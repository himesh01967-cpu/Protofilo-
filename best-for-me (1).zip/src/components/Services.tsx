import { useState } from "react";
import { Plus } from "lucide-react";
import { cn } from "@/utils/cn";
import { services } from "@/lib/data";
import Marquee from "./Marquee";
import { Reveal, Section, SectionHead } from "./UI";

export default function Services() {
  const [open, setOpen] = useState<string | null>(services[0].num);

  return (
    <>
      <div className="border-y border-ink/12 bg-ink py-3 text-paper">
        <Marquee
          items={[
            "how I can help",
            "two slots open for Q3",
            "fixed scope, honest quotes",
            "no retainers without a prototype",
          ]}
          speed={40}
          reverse
          size="sm"
          separator="—"
          className="text-paper/80"
        />
      </div>

      <Section id="services" className="bg-paper-2">
        <SectionHead
          index="03"
          kicker="Services"
          title={
            <>
              Four ways
              <br />
              to use me
            </>
          }
          intro={
            <>
              <p>
                Engagements are scoped by outcome, not hours. You always know what lands in your
                repo, when, and how it will be measured.
              </p>
              <a
                href="#contact"
                className="link-underline w-fit text-[0.78rem] font-semibold uppercase tracking-[0.16em] text-blue"
              >
                Not sure which one? Ask me →
              </a>
            </>
          }
        />

        <ul className="mt-14 border-t border-ink/15">
          {services.map((s, i) => {
            const isOpen = open === s.num;
            return (
              <Reveal as="li" key={s.num} delay={i * 60} className="border-b border-ink/15">
                <button
                  onClick={() => setOpen(isOpen ? null : s.num)}
                  aria-expanded={isOpen}
                  className="group flex w-full items-start gap-5 py-6 text-left sm:gap-10 sm:py-8"
                >
                  <span
                    className={cn(
                      "tabular mt-1 font-display text-lg transition-colors",
                      isOpen ? "text-coral" : "text-mute group-hover:text-blue",
                    )}
                  >
                    {s.num}
                  </span>
                  <span className="flex-1">
                    <span className="block font-display text-[clamp(1.45rem,3.6vw,2.5rem)] uppercase leading-[0.95] transition-transform duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:translate-x-2">
                      {s.title}
                    </span>
                    <span
                      className={cn(
                        "mt-1.5 block text-[0.95rem] italic transition-colors",
                        isOpen ? "text-blue" : "text-mute",
                      )}
                    >
                      {s.line}
                    </span>
                  </span>
                  <span
                    className={cn(
                      "grid h-11 w-11 shrink-0 place-items-center rounded-full border transition-all duration-500",
                      isOpen
                        ? "rotate-[135deg] border-coral bg-coral text-paper"
                        : "border-ink/20 text-ink group-hover:border-ink group-hover:bg-ink group-hover:text-paper",
                    )}
                  >
                    <Plus className="h-4.5 w-4.5" />
                  </span>
                </button>

                <div
                  className="grid transition-[grid-template-rows] duration-700 ease-[cubic-bezier(0.16,1,0.3,1)]"
                  style={{ gridTemplateRows: isOpen ? "1fr" : "0fr" }}
                >
                  <div className="overflow-hidden">
                    <div className="grid gap-8 pb-9 sm:grid-cols-12 sm:pl-14">
                      <p className="text-[0.98rem] leading-relaxed text-ink/75 sm:col-span-6">
                        {s.body}
                      </p>
                      <div className="sm:col-span-3">
                        <p className="label mb-3 text-mute">Deliverables</p>
                        <ul className="flex flex-col gap-2">
                          {s.deliverables.map((d) => (
                            <li key={d} className="flex items-center gap-2 text-sm text-ink/80">
                              <span className="h-1.5 w-1.5 rounded-full bg-blue" />
                              {d}
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div className="sm:col-span-3">
                        <p className="label mb-3 text-mute">Investment</p>
                        <p className="font-display text-xl uppercase text-ink">{s.rate}</p>
                        <a
                          href="#contact"
                          className="mt-4 inline-flex items-center gap-2 rounded-full border border-ink/25 px-4 py-2 text-[0.7rem] font-semibold uppercase tracking-[0.14em] transition-colors hover:border-ink hover:bg-ink hover:text-paper"
                        >
                          Enquire
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </ul>
      </Section>
    </>
  );
}
