import { useCallback, useEffect, useRef, useState } from "react";
import { Check, Dices, RotateCcw } from "lucide-react";
import { cn } from "@/utils/cn";
import { Reveal, Section, SectionHead } from "./UI";

export default function Lab() {
  return (
    <Section id="lab" className="bg-paper-2">
      <SectionHead
        index="06"
        kicker="The lab"
        title={
          <>
            Things I build
            <br />
            on Sundays
          </>
        }
        intro={
          <p>
            Unbriefed experiments keep my hands sharp. Everything below is live — poke it, drag it,
            copy from it. None of it has a product manager.
          </p>
        }
      />

      <div className="mt-14 grid gap-5 lg:grid-cols-12">
        <Reveal className="lg:col-span-7">
          <DotField />
        </Reveal>
        <div className="grid gap-5 lg:col-span-5">
          <Reveal delay={90}>
            <KineticType />
          </Reveal>
          <Reveal delay={160}>
            <PaletteForge />
          </Reveal>
        </div>
      </div>

      <Notes />
    </Section>
  );
}

/* ------------------------------------------------------------------ */
/* 4. Field notes — expandable notes, no dead links                   */
/* ------------------------------------------------------------------ */
const notes = [
  {
    date: "Feb 2026",
    read: "6 min",
    title: "Your easing curve is a brand asset",
    body: "Teams spend months on a logotype and then let every transition default to `ease`. Write down one acceleration profile, put the numbers in the motion bible, and wire it into the token pipeline. Kinetik did this: support tickets about 'the app feels different from the site' stopped, because the physics were the same.",
  },
  {
    date: "Dec 2025",
    read: "9 min",
    title: "The 1GB RAM test",
    body: "Before any launch I run the build on a five-year-old mid-ranger on a throttled 3G profile, with the battery at 15%. It is humbling, it takes an hour, and it has never once been a waste of time. Desktop Safari numbers are a fantasy; that phone in a hand in Pune is the audit.",
  },
  {
    date: "Sep 2025",
    read: "4 min",
    title: "Design systems die in the docs",
    body: "Not in the components — everyone writes good components. They die because nobody documented when not to use something, who owns a token, and what happens to a request in week nine. Budget half the engagement for the boring paperwork and the system still works after I leave.",
  },
];

function Notes() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <div className="mt-20 border-t border-ink/15 pt-10">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <h3 className="font-display text-[clamp(1.6rem,4vw,2.6rem)] uppercase leading-none">
          Field notes
        </h3>
        <p className="label text-mute">Written between projects · click to read</p>
      </div>
      <ul className="grid gap-4 lg:grid-cols-3">
        {notes.map((n, i) => {
          const isOpen = open === i;
          return (
            <Reveal as="li" key={n.title} delay={i * 90}>
              <button
                onClick={() => setOpen(isOpen ? null : i)}
                aria-expanded={isOpen}
                className={cn(
                  "flex h-full w-full flex-col border p-5 text-left transition-all duration-500",
                  isOpen
                    ? "border-ink bg-ink text-paper"
                    : "border-ink/15 bg-paper hover:-translate-y-1 hover:border-ink",
                )}
              >
                <span
                  className={cn(
                    "label mb-4 flex items-center gap-3",
                    isOpen ? "text-lime" : "text-mute",
                  )}
                >
                  {n.date}
                  <span className="h-1 w-1 rounded-full bg-current" />
                  {n.read}
                </span>
                <span className="font-display text-[1.35rem] uppercase leading-[1.05]">
                  {n.title}
                </span>
                <span
                  className="grid transition-[grid-template-rows] duration-700 ease-[cubic-bezier(0.16,1,0.3,1)]"
                  style={{ gridTemplateRows: isOpen ? "1fr" : "0fr" }}
                >
                  <span
                    className={cn(
                      "overflow-hidden text-[0.92rem] leading-relaxed",
                      isOpen ? "mt-4 text-paper/75" : "text-ink/70",
                    )}
                  >
                    {n.body}
                  </span>
                </span>
                <span
                  className={cn(
                    "label mt-5 inline-flex items-center gap-2 transition-colors",
                    isOpen ? "text-lime" : "text-blue",
                  )}
                >
                  {isOpen ? "Close note" : "Read note"}
                  <span
                    className={cn(
                      "block h-[2px] w-6 transition-transform duration-500",
                      isOpen ? "scale-x-150 bg-lime" : "bg-blue",
                    )}
                  />
                </span>
              </button>
            </Reveal>
          );
        })}
      </ul>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* 1. Pointer-reactive dot field (canvas, paused when off-screen)      */
/* ------------------------------------------------------------------ */
function DotField() {
  const host = useRef<HTMLDivElement | null>(null);
  const cvs = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = cvs.current;
    const box = host.current;
    if (!canvas || !box) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = Math.min(2, window.devicePixelRatio || 1);
    let w = 0;
    let h = 0;
    let raf = 0;
    let visible = true;
    const gap = 28;
    type Dot = { x: number; y: number; ox: number; oy: number; vx: number; vy: number };
    let dots: Dot[] = [];
    const p = { x: -9999, y: -9999, on: false };

    const build = () => {
      const r = box.getBoundingClientRect();
      w = r.width;
      h = r.height;
      canvas.width = Math.max(1, Math.round(w * dpr));
      canvas.height = Math.max(1, Math.round(h * dpr));
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      dots = [];
      for (let y = gap / 2; y < h; y += gap)
        for (let x = gap / 2; x < w; x += gap) dots.push({ x, y, ox: x, oy: y, vx: 0, vy: 0 });
    };

    const io = new IntersectionObserver(
      ([e]) => {
        visible = e.isIntersecting;
      },
      { threshold: 0.05 },
    );
    io.observe(box);

    const pointer = (e: PointerEvent) => {
      const r = canvas.getBoundingClientRect();
      p.x = e.clientX - r.left;
      p.y = e.clientY - r.top;
      p.on = true;
    };
    const leave = () => {
      p.on = false;
      p.x = -9999;
      p.y = -9999;
    };

    const draw = () => {
      raf = requestAnimationFrame(draw);
      if (!visible) return;
      ctx.clearRect(0, 0, w, h);
      const R = 130;
      for (const d of dots) {
        const dx = d.x - p.x;
        const dy = d.y - p.y;
        const dist = Math.hypot(dx, dy);
        if (p.on && dist < R) {
          const f = ((R - dist) / R) ** 2 * 12;
          d.vx += (dx / (dist || 1)) * f;
          d.vy += (dy / (dist || 1)) * f;
        }
        d.vx += (d.ox - d.x) * 0.09;
        d.vy += (d.oy - d.y) * 0.09;
        d.vx *= 0.82;
        d.vy *= 0.82;
        d.x += d.vx;
        d.y += d.vy;

        const speed = Math.min(1, Math.hypot(d.vx, d.vy) / 9);
        const rad = 1.1 + speed * 3.4;
        ctx.beginPath();
        ctx.arc(d.x, d.y, rad, 0, Math.PI * 2);
        ctx.fillStyle =
          speed > 0.08
            ? `rgba(255,75,38,${0.35 + speed * 0.65})`
            : "rgba(18,20,26,0.30)";
        ctx.fill();
      }
    };

    build();
    draw();
    const ro = new ResizeObserver(build);
    ro.observe(box);
    canvas.addEventListener("pointermove", pointer);
    canvas.addEventListener("pointerleave", leave);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      io.disconnect();
      canvas.removeEventListener("pointermove", pointer);
      canvas.removeEventListener("pointerleave", leave);
    };
  }, []);

  const [resetKey, setResetKey] = useState(0);
  return (
    <div
      className="relative h-full min-h-[20rem] overflow-hidden border border-ink/15 bg-paper"
      ref={host}
    >
      <canvas key={resetKey} ref={cvs} className="absolute inset-0 h-full w-full" />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 flex items-end justify-between p-5">
        <div>
          <p className="label text-mute">Exhibit A · Repulsion field</p>
          <p className="mt-1 font-display text-xl uppercase">Move your cursor through it</p>
        </div>
        <p className="pointer-events-auto">
          <button
            onClick={() => setResetKey((k) => k + 1)}
            className="grid h-10 w-10 place-items-center rounded-full border border-ink/20 bg-paper text-ink transition-colors hover:border-ink hover:bg-ink hover:text-paper"
            aria-label="Reset field"
          >
            <RotateCcw className="h-4 w-4" />
          </button>
        </p>
      </div>
      <div className="pointer-events-none absolute inset-0 hatch opacity-40" />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* 2. Kinetic type controls                                             */
/* ------------------------------------------------------------------ */
const FONTS = [
  { label: "Anton", value: '"Anton", sans-serif', weight: 400 },
  { label: "Grotesk", value: '"Space Grotesk", sans-serif', weight: 600 },
  { label: "Serif", value: '"Instrument Serif", serif', weight: 400 },
];

function KineticType() {
  const [text, setText] = useState("SHIP IT");
  const [size, setSize] = useState(72);
  const [track, setTrack] = useState(-2);
  const [weight, setWeight] = useState(600);
  const [skew, setSkew] = useState(0);
  const [font, setFont] = useState(0);
  const [outline, setOutline] = useState(false);

  return (
    <div className="border border-ink/15 bg-paper p-5 sm:p-6">
      <div className="flex items-center justify-between">
        <p className="label text-mute">Exhibit B · Type rig</p>
        <div className="flex gap-1.5">
          {FONTS.map((f, i) => (
            <button
              key={f.label}
              onClick={() => setFont(i)}
              className={cn(
                "rounded-full border px-3 py-1 text-[0.66rem] font-semibold uppercase tracking-[0.12em] transition-colors",
                font === i
                  ? "border-ink bg-ink text-paper"
                  : "border-ink/20 text-ink/60 hover:border-ink",
              )}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      <div
        className="mt-5 grid min-h-[8.5rem] place-items-center overflow-hidden border border-ink/12 bg-paper-2 px-4 py-5 text-center"
        style={{
          fontFamily: FONTS[font].value,
          fontSize: `${size}px`,
          letterSpacing: `${track / 100}em`,
          fontWeight: font === 1 ? weight : FONTS[font].weight,
          transform: `skewY(${skew}deg)`,
          WebkitTextStroke: outline ? "1.5px #12141a" : undefined,
          color: outline ? "transparent" : "#12141a",
          lineHeight: 0.95,
        }}
      >
        {text || "TYPE HERE"}
      </div>

      <label className="mt-4 block">
        <span className="sr-only">Sample text</span>
        <input
          value={text}
          maxLength={22}
          onChange={(e) => setText(e.target.value.toUpperCase())}
          className="w-full border-b border-ink/25 bg-transparent py-2 text-sm uppercase tracking-[0.1em] outline-none transition-colors focus:border-blue"
          placeholder="Type something"
        />
      </label>

      <div className="mt-4 grid grid-cols-2 gap-x-6 gap-y-3 sm:grid-cols-4">
        <Slider label="size" value={size} min={28} max={120} onChange={setSize} />
        <Slider label="weight" value={weight} min={300} max={700} step={10} onChange={setWeight} disabled={font !== 1} />
        <Slider label="track" value={track} min={-6} max={24} onChange={setTrack} />
        <Slider label="skew" value={skew} min={-12} max={12} onChange={setSkew} />
      </div>

      <button
        onClick={() => setOutline((v) => !v)}
        className={cn(
          "mt-4 w-full rounded-full border py-2.5 text-[0.7rem] font-semibold uppercase tracking-[0.16em] transition-colors",
          outline
            ? "border-blue bg-blue text-paper"
            : "border-ink/20 text-ink/70 hover:border-ink hover:bg-ink hover:text-paper",
        )}
      >
        {outline ? "Filled" : "Switch to outline"}
      </button>
    </div>
  );
}

function Slider({
  label,
  value,
  min,
  max,
  step = 1,
  onChange,
  disabled,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  onChange: (v: number) => void;
  disabled?: boolean;
}) {
  return (
    <label className={cn("block", disabled && "opacity-40")}>
      <span className="label flex items-center justify-between text-mute">
        {label}
        <span className="tabular text-ink">{value}</span>
      </span>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        disabled={disabled}
        onChange={(e) => onChange(Number(e.target.value))}
        className="mt-2 h-1 w-full appearance-none rounded-full bg-ink/20 accent-blue outline-none"
      />
    </label>
  );
}

/* ------------------------------------------------------------------ */
/* 3. Palette forge                                                     */
/* ------------------------------------------------------------------ */
function hslToHex(h: number, s: number, l: number) {
  const a = (s / 100) * Math.min(l / 100, 1 - l / 100);
  const f = (n: number) => {
    const k = (n + h / 30) % 12;
    const c = l / 100 - a * Math.max(-1, Math.min(k - 3, Math.min(9 - k, 1)));
    return Math.round(255 * c)
      .toString(16)
      .padStart(2, "0");
  };
  return `#${f(0)}${f(8)}${f(4)}`.toUpperCase();
}

function PaletteForge() {
  const make = useCallback(
    () =>
      Array.from({ length: 5 }, (_, i) => {
        const h = (Math.random() * 360 + i * 26) % 360;
        const s = 55 + Math.random() * 40;
        const l = 20 + i * 13;
        return { hex: hslToHex(h, s, l), h, s: Math.round(s), l: Math.round(l) };
      }),
    [],
  );
  const [swatches, setSwatches] = useState(make);
  const [copied, setCopied] = useState<string | null>(null);

  return (
    <div className="border border-ink/15 bg-paper p-5 sm:p-6">
      <div className="flex items-center justify-between">
        <p className="label text-mute">Exhibit C · Palette forge</p>
        <button
          onClick={() => setSwatches(make())}
          className="group inline-flex items-center gap-2 rounded-full border border-ink/20 px-3.5 py-1.5 text-[0.68rem] font-semibold uppercase tracking-[0.14em] transition-colors hover:border-ink hover:bg-ink hover:text-paper"
        >
          <Dices className="h-3.5 w-3.5 transition-transform duration-500 group-hover:rotate-[180deg]" />
          Reroll
        </button>
      </div>

      <div className="mt-5 grid grid-cols-5 gap-1.5">
        {swatches.map((s) => (
          <button
            key={s.hex}
            onClick={async () => {
              try {
                await navigator.clipboard.writeText(s.hex);
              } catch {
                /* ignore */
              }
              setCopied(s.hex);
              window.setTimeout(() => setCopied((v) => (v === s.hex ? null : v)), 1400);
            }}
            title={`Copy ${s.hex}`}
            className="group relative aspect-[3/4] overflow-hidden rounded-[3px] transition-transform duration-500 hover:-translate-y-1.5"
            style={{ background: s.hex }}
          >
            <span
              className="absolute inset-x-1 bottom-1 text-[0.55rem] font-semibold uppercase tracking-[0.08em] opacity-0 transition-opacity duration-300 group-hover:opacity-100"
              style={{ color: s.l > 55 ? "#12141a" : "#ece9e1" }}
            >
              {copied === s.hex ? "copied" : s.hex.slice(1)}
            </span>
            {copied === s.hex && (
              <Check
                className="absolute left-1 top-1 h-3 w-3"
                style={{ color: s.l > 55 ? "#12141a" : "#ece9e1" }}
              />
            )}
          </button>
        ))}
      </div>

      <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-ink/12 pt-4">
        <p className="text-[0.78rem] text-mute">
          Harmonised: 26° hue steps, lightness ramp 20→72. Click a swatch to copy.
        </p>
        <p className="tabular label text-ink/50">
          {swatches.map((s) => s.h.toFixed(0)).join(" / ")}°
        </p>
      </div>
    </div>
  );
}
