#!/usr/bin/env python3
"""Bundle index.html + styles.css + app.js + fonts + the 24 WebP assets into one
self-contained HTML file (leon-vasari.html). No network required at runtime."""
import base64, re, pathlib

root = pathlib.Path(__file__).parent
html = (root / 'index.html').read_text()
css  = (root / 'styles.css').read_text()
fonts= (root / 'fonts' / 'fonts.css').read_text()
js   = (root / 'app.js').read_text()

# fonts: already base64 data URLs
css = fonts + "\n" + css

# inline the spine/cover WebP files as data URIs
def datauri(p):
    return 'data:image/webp;base64,' + base64.b64encode((root / p).read_bytes()).decode()

ids = re.findall(r"id:'([a-z]+)'", js)
# swap the two dynamic builders for table lookups FIRST, before any data lands in the file
js = js.replace("'assets/' + f.id + '-s.webp'", "_D[f.id + '-s']")
js = js.replace("'assets/' + f.id + '-c.webp'", "_D[f.id + '-c']")
assert "'assets/' + f.id" not in js

# replace the two dynamic asset builders with a lookup table of data URIs
lookup = "const _D = {" + ",".join(
    "'%s-%s':'%s'" % (f, k, datauri(f'assets/{f}-{k}.webp'))
    for f in ids for k in ('s', 'c')) + "};\n"
js = js.replace("(function () {\n  'use strict';\n", "(function () {\n  'use strict';\n  " + lookup, 1)

# webp for the <image> href is set from f.cover, which is now a data URI too

out = html.replace('<link rel="stylesheet" href="fonts/fonts.css">\n<link rel="stylesheet" href="styles.css">',
                   '<style>\n' + css + '\n</style>')
out = out.replace('<script src="app.js"></script>', '<script>\n' + js + '\n</script>')
assert 'href="styles.css"' not in out and 'src="app.js"' not in out
(root / 'leon-vasari.html').write_text(out)
print('wrote leon-vasari.html', round((root / 'leon-vasari.html').stat().st_size / 1e6, 2), 'MB')
