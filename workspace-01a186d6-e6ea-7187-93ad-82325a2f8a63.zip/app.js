/* ============================================================
   LEON VASARI — VHS FILMOGRAPHY SHELF
   One rAF loop + Web Animations API. No CSS keyframes, no opacity
   fades anywhere: every reveal is a mask slide, a clip or a scale.

   Assets are the 24 WebP files from the Higgsfield CloudFront CDN,
   mirrored byte-for-byte into ./assets so the shelf works offline.
   CDN originals:
     spines  https://d2ol7oe51mr4n9.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/<id>.webp
     covers  https://d2ol7oe51mr4n9.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/<id>.webp
   ============================================================ */
(function () {
  'use strict';

  /* ---------------- DATA ---------------- */
  const FILMS = [
    { id:'valley',   title:'The Silent Valley', romaji:'SHIZUKANA TANI', kanji:'静かな谷', year:1958, genre:'Drama',    min:104, syn:'A schoolteacher returns to the mountain village that exiled her father, and finds the valley has kept every one of its secrets.' },
    { id:'bluehour', title:'The Blue Hour',      romaji:'AO NO TOKI',     kanji:'青の刻',   year:1962, genre:'Romance',  min:97,  syn:'Over one long evening in a harbour town, a widow and a stranger trade small lies until the light runs out.' },
    { id:'river',    title:'River of Salt',      romaji:'SHIO NO KAWA',   kanji:'塩の川',   year:1964, genre:'Drama',    min:121, syn:'Two brothers drag a salt barge downriver to a city that no longer wants anything they carry.' },
    { id:'summer',   title:'The Last Summer',    romaji:'SAIGO NO NATSU', kanji:'最後の夏', year:1966, genre:'Drama',    min:109, syn:'The summer before the dam floods their village, three friends set fire to everything they cannot take with them.' },
    { id:'green',    title:'The Green Road',     romaji:'MIDORI NO MICHI',kanji:'緑の道',   year:1969, genre:'Mystery',  min:101, syn:'A surveyor mapping a forest road keeps finding the same footprints, always one day ahead of him.' },
    { id:'noon',     title:'Noon in Ashes',      romaji:'HAI NO SHOGO',   kanji:'灰の正午', year:1971, genre:'Western',  min:112, syn:'A rider crosses a white desert to settle an old debt, and learns too late who sent him.' },
    { id:'observer', title:'The Observer',       romaji:'KANSATSUSHA',    kanji:'観察者',   year:1973, genre:'Thriller', min:96,  syn:'A night watchman begins to suspect that the building he guards has started watching him back.' },
    { id:'birds',    title:'The Fallen Birds',   romaji:'OCHITA TORI',    kanji:'落ちた鳥', year:1975, genre:'Drama',    min:118, syn:'When the birds stop singing over a frontier town, the mayor\u2019s daughter is the only one who goes looking for the reason.' },
    { id:'storm',    title:'Light in the Storm', romaji:'ARASHI NO HI',   kanji:'嵐の灯',   year:1978, genre:'Drama',    min:127, syn:'A lighthouse keeper and his son wait out a three-day storm with a shipwrecked sailor who will not give his name.' },
    { id:'tide',     title:'The Long Tide',      romaji:'NAGAI SHIO',     kanji:'長い潮',   year:1981, genre:'Drama',    min:99,  syn:'A fisherman\u2019s wife counts the tides on the harbour wall while her husband\u2019s boat fails to come home.' },
    { id:'war',      title:'A Quiet War',        romaji:'SHIZUKANA SENSO',kanji:'静かな戦争',year:1985,genre:'Comedy',   min:103, syn:'Two neighbours fight a silent war over a garden wall for thirty years, and neither will say how it began.' },
    { id:'door',     title:'Red Door',           romaji:'AKAI TOBIRA',    kanji:'赤い扉',   year:1989, genre:'Thriller', min:114, syn:'A projectionist follows a reel of unknown film through the corridors of a cinema on its final night.' }
  ].map(f => Object.assign(f, {
    spine: 'assets/' + f.id + '-s.webp',
    cover: 'assets/' + f.id + '-c.webp'
  }));

  const N = FILMS.length;          // 12
  const COPIES = 3;                // 36 tapes on the endless shelf
  const TOTAL = N * COPIES;
  const HALF = TOTAL / 2;          // 18

  /* ---------------- DOM ---------------- */
  const $  = s => document.querySelector(s);
  const $$ = s => Array.prototype.slice.call(document.querySelectorAll(s));

  const root      = document.documentElement;
  const stage     = $('#stage');
  const shelfEl   = $('#shelf');
  const detail    = $('#detail');
  const posterImg = $('#posterImg');
  const blobs     = $$('.blob');
  const cursorEl  = $('#cursor');
  const playring  = $('#playring');
  const tabsEl    = $('.tabs');
  const tabInd    = $('.tab-ind');
  const tabBtns   = $$('.tab');
  const dRise     = $$('.d-left .rise');
  const reduce    = window.matchMedia('(prefers-reduced-motion: reduce)');

  /* ---------------- STATE ---------------- */
  const st = {
    s: 5 + N,            // scroll position, opens on Noon in Ashes (index 5) in the middle copy
    T: 5 + N,
    active: 5,
    hover: -1,
    mx: window.innerWidth / 2,
    my: window.innerHeight / 2,
    cx: window.innerWidth / 2,
    cy: window.innerHeight / 2,
    tiltX: 0,
    tiltY: 0,
    onCover: false,
    overBtn: false,
    isOpen: false,
    dragging: false,
    wheelTimer: 0,
    suppressClick: false
  };

  let H = 0, WS = 0, D = 0, GAP = 0;

  /* ---------------- GEOMETRY ---------------- */
  function measure() {
    const probe = document.createElement('div');
    probe.style.cssText = 'position:absolute;left:-9999px;top:0;width:1px;height:var(--H);';
    document.body.appendChild(probe);
    H = probe.getBoundingClientRect().height;
    probe.remove();

    WS  = H * 142 / 840;
    D   = H * 474 / 900;
    GAP = H * 0.03;

    root.style.setProperty('--ws', WS + 'px');
    root.style.setProperty('--d',  D  + 'px');
    stage.style.setProperty('--ws', WS + 'px');
    stage.style.setProperty('--d',  D  + 'px');

    placeIndicator(true);
  }

  /* ---------------- BUILD THE SHELF ---------------- */
  const tapes = [];
  function buildShelf() {
    const frag = document.createDocumentFragment();
    for (let copy = 0; copy < COPIES; copy++) {
      for (let i = 0; i < N; i++) {
        const film = FILMS[i];
        const v = copy * N + i;

        const el = document.createElement('div');
        el.className = 'tape';
        el.setAttribute('role', 'button');
        el.setAttribute('aria-label', film.title + ', ' + film.year);

        const sp = document.createElement('div');
        sp.className = 'sp';
        sp.style.backgroundImage = 'url("' + film.spine + '")';

        const cv = document.createElement('div');
        cv.className = 'cv';
        cv.style.backgroundImage = 'url("' + film.cover + '")';

        el.appendChild(sp);
        el.appendChild(cv);
        frag.appendChild(el);

        const rec = { el, sp, cv, v, i, lift: 0, liftTarget: 0, visible: true, r: 0 };

        el.addEventListener('pointerenter', () => { st.hover = v; });
        el.addEventListener('pointerleave', () => { if (st.hover === v) st.hover = -1; });

        el.addEventListener('click', e => {
          if (st.suppressClick) return;
          e.stopPropagation();
          if (Math.abs(rec.r) < 0.5) openDetail();
          else st.T = Math.round(st.T + rec.r);
        });

        tapes.push(rec);
      }
    }
    stage.appendChild(frag);
  }

  /* ---------------- MATH ---------------- */
  const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
  const smoothstep = t => { t = clamp(t, 0, 1); return t * t * (3 - 2 * t); };
  const B = r => Math.abs(r) < 1 ? (r + Math.sin(Math.PI * r) / Math.PI) / 2 : (r < 0 ? -0.5 : 0.5);
  const wrapFilm = i => ((i % N) + N) % N;

  /* ---------------- CAPTION ---------------- */
  const capTitle = $('#capTitle'), capSub = $('#capSub'), capYear = $('#capYear');

  function setLine(maskHost, text, dir, animate) {
    const old = Array.prototype.slice.call(maskHost.children);
    const el = document.createElement('span');
    el.className = 'mline';
    el.textContent = text;
    maskHost.appendChild(el);

    if (!animate || reduce.matches) {
      old.forEach(o => o.remove());
      el.style.transform = 'translateY(0)';
      return;
    }

    const EASE = 'cubic-bezier(.2,.8,.2,1)';
    el.animate(
      [{ transform: 'translateY(' + (dir * 105) + '%)' }, { transform: 'translateY(0)' }],
      { duration: 650, easing: EASE, fill: 'both' }
    );

    old.forEach(o => {
      if (o.dataset.leaving) return;
      o.dataset.leaving = '1';
      const cs = getComputedStyle(o).transform;
      const from = (!cs || cs === 'none') ? 'translateY(0)' : cs;
      const a = o.animate(
        [{ transform: from }, { transform: 'translateY(' + (-dir * 105) + '%)' }],
        { duration: 650, easing: EASE, fill: 'both' }
      );
      a.onfinish = () => o.remove();
      a.oncancel = () => o.remove();
    });
  }

  function setActive(idx, dir) {
    if (idx === st.active && capTitle.children.length) { placeIndicator(); return; }
    st.active = idx;
    const f = FILMS[idx];
    const animate = true;
    setLine(capTitle, f.title, dir, animate);
    setLine(capSub,   f.romaji + ' / ' + f.kanji, dir, animate);
    setLine(capYear,  String(f.year), dir, animate);
    placeIndicator();
  }

  function placeIndicator(instant) {
    const f = FILMS[st.active];
    const decade = String(Math.floor(f.year / 10) * 10);
    let target = tabBtns.find(b => b.dataset.decade === decade) || tabBtns[1];
    if (instant) {
      tabInd.style.transition = 'none';
      tabInd.style.width = target.offsetWidth + 'px';
      tabInd.style.transform = 'translateX(' + target.offsetLeft + 'px)';
      void tabInd.offsetWidth;
      tabInd.style.transition = '';
    } else {
      tabInd.style.width = target.offsetWidth + 'px';
      tabInd.style.transform = 'translateX(' + target.offsetLeft + 'px)';
    }
    tabBtns.forEach(b => b.classList.toggle('active', b === target));
  }

  /* ---------------- CURSOR ---------------- */
  let cursorState = '';
  function setCursorState(s) {
    if (s === cursorState) return;
    cursorState = s;
    cursorEl.classList.remove('spine', 'btn', 'open');
    if (s !== 'default') cursorEl.classList.add(s);
  }

  /* ---------------- FRAME LOOP ---------------- */
  let last = performance.now();
  let prevActive = st.active;

  function frame(now) {
    const dt = Math.min((now - last) / 1000, 0.05);
    last = now;

    const W = window.innerWidth;
    const Hgt = window.innerHeight;
    const cyShelf = Hgt / 2;

    /* --- spring --- */
    const k = reduce.matches ? 1 : (st.dragging ? 18 : 5.2);
    if (!st.isOpen) {
      st.s += (st.T - st.s) * (1 - Math.exp(-k * dt));
      if (Math.abs(st.T - st.s) < 1e-4) st.s = st.T;
    }

    /* --- normalise the endless shelf --- */
    if (st.s > TOTAL * 4 || st.s < -TOTAL * 4) {
      const shift = Math.round(st.s / TOTAL) * TOTAL;
      st.s -= shift; st.T -= shift;
    }

    /* --- caption / active film --- */
    const dir = st.T < st.s ? -1 : 1;
    const activeIdx = wrapFilm(Math.round(st.s));
    if (activeIdx !== prevActive) {
      prevActive = activeIdx;
      setActive(activeIdx, dir);
    }

    /* --- tilt towards the cursor --- */
    const coverHit = !st.isOpen &&
      Math.abs(st.mx - W / 2) < 0.55 * D &&
      Math.abs(st.my - cyShelf) < 0.55 * H &&
      Math.abs(st.T - st.s) < 0.3;
    st.onCover = coverHit;

    let tTiltY, tTiltX;
    if (coverHit) {
      tTiltY = ((st.mx - W / 2) / (0.55 * D)) * 9;
      tTiltX = -((st.my - cyShelf) / (H / 2)) * 6;
    } else {
      tTiltY = ((st.mx - W / 2) / W) * 5;
      tTiltX = 0;
    }
    const tEase = reduce.matches ? 1 : (1 - Math.exp(-7 * dt));
    st.tiltY += (tTiltY - st.tiltY) * tEase;
    st.tiltX += (tTiltX - st.tiltX) * tEase;

    /* --- tapes --- */
    for (let n = 0; n < tapes.length; n++) {
      const t = tapes[n];

      let r = ((t.v - st.s) % TOTAL + TOTAL) % TOTAL;
      if (r >= HALF) r -= TOTAL;
      t.r = r;

      const x = r * (WS + GAP) + (D - WS + 1.6 * GAP) * B(r);

      if (Math.abs(x) > W / 2 + 1.5 * D) {
        if (t.visible) { t.el.style.visibility = 'hidden'; t.visible = false; }
        continue;
      }
      if (!t.visible) { t.el.style.visibility = 'visible'; t.visible = true; }

      /* hover lift */
      if (Math.abs(r) < 0.5 && st.hover === t.v) t.liftTarget = 0;
      else if (Math.abs(r) > 0.5 && st.hover === t.v) t.liftTarget = 1;
      else t.liftTarget = 0;
      t.lift += (t.liftTarget - t.lift) * (reduce.matches ? 1 : (1 - Math.exp(-12 * dt)));

      /* openness */
      const o = smoothstep(Math.max(0, 1 - Math.abs(r)));

      const rotY = -90 * o + st.tiltY * o;
      const rotX = st.tiltX * o;
      const rotZ = -4.5 * o;
      const tz = o * 0.2 * H;
      const ty = -o * 0.025 * H - t.lift * 0.045 * H;

      t.el.style.transform =
        'translate3d(' + x.toFixed(2) + 'px,' + ty.toFixed(2) + 'px,' + tz.toFixed(2) + 'px)' +
        ' rotateZ(' + rotZ.toFixed(3) + 'deg)' +
        ' rotateX(' + rotX.toFixed(3) + 'deg)' +
        ' rotateY(' + rotY.toFixed(3) + 'deg)';
      t.el.style.zIndex = String(Math.round(100 - Math.abs(r)) + (o > 0.001 ? 60 : 0));

      /* light falling across a turning object */
      t.sp.style.setProperty('--shade', (o * 0.55).toFixed(3));
      t.cv.style.setProperty('--shade', ((1 - o) * 0.5).toFixed(3));
    }

    /* --- play ring --- */
    const ringScale = st.isOpen ? 0 : smoothstep(Math.max(0, 1 - Math.abs(st.T - st.s) * 3));
    playring.style.transform = 'scale(' + ringScale.toFixed(4) + ')';
    playring.style.pointerEvents = ringScale > 0.6 ? 'auto' : 'none';

    /* --- cursor --- */
    st.cx += (st.mx - st.cx) * (1 - Math.exp(-16 * dt));
    st.cy += (st.my - st.cy) * (1 - Math.exp(-16 * dt));
    cursorEl.style.transform = 'translate3d(' + st.cx.toFixed(2) + 'px,' + st.cy.toFixed(2) + 'px,0)';

    let cs = 'default';
    if (!st.isOpen && st.onCover) cs = 'open';
    else if (st.overBtn) cs = 'btn';
    else if (!st.isOpen && st.hover >= 0) cs = 'spine';
    setCursorState(cs);

    requestAnimationFrame(frame);
  }

  /* ---------------- INPUT ---------------- */
  window.addEventListener('pointermove', e => {
    st.mx = e.clientX;
    st.my = e.clientY;
  }, { passive: true });

  document.addEventListener('pointerover', e => {
    const el = e.target.closest && e.target.closest('button, a');
    st.overBtn = !!(el && !el.closest('.shelf'));
  });
  document.addEventListener('pointerout', e => {
    if (!e.relatedTarget) st.overBtn = false;
  });

  /* arrows */
  $('#prev').addEventListener('click', () => { if (!st.isOpen) st.T = Math.round(st.T) - 1; });
  $('#next').addEventListener('click', () => { if (!st.isOpen) st.T = Math.round(st.T) + 1; });

  /* play ring */
  playring.addEventListener('click', e => { e.stopPropagation(); openDetail(); });

  /* decade tabs */
  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      if (st.isOpen) return;
      const d = btn.dataset.decade;
      const cur = wrapFilm(Math.round(st.s));
      let ti;
      if (d === 'all') ti = 0;
      else {
        ti = FILMS.findIndex(f => String(Math.floor(f.year / 10) * 10) === d);
        if (ti < 0) return;
      }
      let diff = ((ti - cur) % N + N) % N;
      if (diff > N / 2) diff -= N;
      st.T = Math.round(st.T) + diff;
    });
  });

  /* keyboard */
  window.addEventListener('keydown', e => {
    if (st.isOpen) {
      if (e.key === 'Escape') { e.preventDefault(); closeDetail(); }
      return;
    }
    const onBody = document.activeElement === document.body ||
                   document.activeElement === null ||
                   document.activeElement === document.documentElement;
    if (e.key === 'ArrowLeft')  { e.preventDefault(); st.T = Math.round(st.T) - 1; }
    if (e.key === 'ArrowRight') { e.preventDefault(); st.T = Math.round(st.T) + 1; }
    if (e.key === 'Enter' && onBody) { e.preventDefault(); openDetail(); }
  });

  /* wheel */
  shelfEl.addEventListener('wheel', e => {
    if (st.isOpen) return;
    e.preventDefault();
    const dx = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY;
    const px = e.deltaMode === 1 ? dx * 16 : dx;
    st.T += px / (WS + GAP) * 0.5;
    clearTimeout(st.wheelTimer);
    st.wheelTimer = setTimeout(() => { st.T = Math.round(st.T); }, 160);
  }, { passive: false });

  /* drag */
  let drag = null;
  shelfEl.addEventListener('pointerdown', e => {
    if (st.isOpen || e.button !== 0) return;
    drag = { x0: e.clientX, T0: st.T, moved: false, id: e.pointerId };
  });
  window.addEventListener('pointermove', e => {
    if (!drag) return;
    const dx = e.clientX - drag.x0;
    if (!drag.moved && Math.abs(dx) > 5) {
      drag.moved = true;
      st.dragging = true;
      st.suppressClick = false;
    }
    if (drag.moved) st.T = drag.T0 - dx / (WS + GAP);
  });
  window.addEventListener('pointerup', e => {
    if (!drag) return;
    if (drag.moved) {
      st.dragging = false;
      st.T = Math.round(st.T);
      st.suppressClick = true;
      setTimeout(() => { st.suppressClick = false; }, 0);
    }
    drag = null;
  });

  /* ============================================================
     DETAIL — paper sheet + ink reveal
     ============================================================ */
  const EASE_SHEET = 'cubic-bezier(.76,0,.18,1)';
  const BLOB_DELAYS = [0, 120, 220, 300, 360, 420, 180]; // per blob, after the 520ms lead-in
  let sheetAnim = null, riseAnims = [], inkRaf = 0;

  function activeCoverEl() {
    const idx = wrapFilm(Math.round(st.s));
    const rec = tapes.find(t => t.i === idx && Math.abs(t.r) < 0.5) ||
                tapes.find(t => t.i === idx && t.visible) ||
                tapes.find(t => t.i === idx);
    return rec ? rec.cv : null;
  }

  function coverRect() {
    const el = activeCoverEl();
    if (!el) return { top: window.innerHeight / 2 - H / 2, left: window.innerWidth / 2 - D / 2,
                     width: D, height: H, right: 0, bottom: 0 };
    return el.getBoundingClientRect();
  }

  function insetFor(rect, round) {
    const W = window.innerWidth, Ht = window.innerHeight;
    return 'inset(' + rect.top + 'px ' + (W - rect.right) + 'px ' +
           (Ht - rect.bottom) + 'px ' + rect.left + 'px round ' + round + ')';
  }

  function fillDetail(f) {
    $('#dSub').textContent = f.romaji + ' / ' + f.kanji;
    $('#dTitle').textContent = f.title;
    $('#dMeta').textContent = f.year + ' / ' + f.genre + ' / ' + f.min + ' MIN';
    $('#dSyn').textContent = f.syn;
    posterImg.setAttribute('href', f.cover);
    posterImg.setAttributeNS('http://www.w3.org/1999/xlink', 'xlink:href', f.cover);
  }

  function resetInk() { blobs.forEach(b => b.setAttribute('r', '0')); }

  function runInk(startAt) {
    cancelAnimationFrame(inkRaf);
    const t0 = startAt || performance.now();
    const stopAt = t0 + (reduce.matches ? 1 : 2400);
    function tick(now) {
      const el = now - t0;
      for (let i = 0; i < blobs.length; i++) {
        const p = reduce.matches ? 1 : clamp((el - 520 - BLOB_DELAYS[i]) / 1250, 0, 1);
        const e = 1 - Math.pow(1 - p, 3);
        blobs[i].setAttribute('r', (e * 720).toFixed(1));
      }
      if (now < stopAt) inkRaf = requestAnimationFrame(tick);
    }
    inkRaf = requestAnimationFrame(tick);
  }

  function openDetail() {
    if (st.isOpen) return;
    st.isOpen = true;

    st.T = Math.round(st.T);
    const idx = wrapFilm(Math.round(st.s));
    const f = FILMS[idx];
    fillDetail(f);
    resetInk();

    const rect = coverRect();

    detail.style.transformOrigin =
      (rect.left + rect.width / 2) + 'px ' + (rect.top + rect.height / 2) + 'px';
    detail.style.visibility = 'visible';

    const from = { clipPath: insetFor(rect, '3px'), transform: 'rotate(-4.5deg)', opacity: 1 };
    const to   = { clipPath: 'inset(0px 0px 0px 0px round 0px)', transform: 'rotate(0deg)', opacity: 1 };

    detail.style.clipPath = '';
    detail.style.transform = '';
    if (reduce.matches) {
      /* no paper growth: the sheet is simply there, full size */
      detail.style.clipPath = to.clipPath;
      detail.style.transform = 'rotate(0deg)';
    } else {
      sheetAnim = detail.animate([from, to], { duration: 1050, easing: EASE_SHEET, fill: 'both' });
    }

    /* text rises out of its masks */
    riseAnims.forEach(a => a.cancel());
    riseAnims = [];
    dRise.forEach((el, i) => {
      if (reduce.matches) { el.style.transform = 'translateY(0)'; return; }
      el.style.transform = '';
      const a = el.animate(
        [{ transform: 'translateY(110%)' }, { transform: 'translateY(0)' }],
        { duration: 900, delay: 620 + i * 75, easing: 'cubic-bezier(.2,.8,.2,1)', fill: 'both' }
      );
      riseAnims.push(a);
    });

    /* poster bleeds in as ink blots */
    runInk(performance.now());


    playring.style.transform = 'scale(0)';
    setCursorState('default');
  }

  function closeDetail() {
    if (!st.isOpen) return;

    const rect = coverRect();
    detail.style.transformOrigin =
      (rect.left + rect.width / 2) + 'px ' + (rect.top + rect.height / 2) + 'px';

    const to = { clipPath: insetFor(rect, '3px'), transform: 'rotate(-4.5deg)', opacity: 1 };

    if (reduce.matches) {
      finishClose();
      return;
    }

    const a = detail.animate([
      { clipPath: 'inset(0px 0px 0px 0px round 0px)', transform: 'rotate(0deg)', opacity: 1 },
      to
    ], { duration: 850, easing: EASE_SHEET, fill: 'both' });
    a.onfinish = () => { a.cancel(); finishClose(); };
  }

  function finishClose() {
    st.isOpen = false;
    detail.style.visibility = 'hidden';
    detail.style.clipPath = '';
    detail.style.transform = '';
    if (detail.getAnimations) detail.getAnimations().forEach(a => a.cancel());
    if (sheetAnim) { try { sheetAnim.cancel(); } catch (e) {} sheetAnim = null; }
    riseAnims.forEach(a => a.cancel());
    riseAnims = [];
    cancelAnimationFrame(inkRaf);
    resetInk();
  }

  $('#closeDetail').addEventListener('click', closeDetail);
  $$('.d-watch').forEach(b => b.addEventListener('click', () => {}));

  /* ---------------- BOOT ---------------- */
  function boot() {
    buildShelf();
    measure();

    /* preload every cover so the first turn never shows an empty face */
    FILMS.forEach(f => { const im = new Image(); im.src = f.cover; });

    /* initial caption, no animation */
    const f = FILMS[st.active];
    setLine(capTitle, f.title, 1, false);
    setLine(capSub, f.romaji + ' / ' + f.kanji, 1, false);
    setLine(capYear, String(f.year), 1, false);
    placeIndicator(true);

    window.addEventListener('resize', () => { measure(); });
    if (reduce.addEventListener) reduce.addEventListener('change', () => {});

    requestAnimationFrame(frame);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
