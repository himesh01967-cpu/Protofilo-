# Leon Vasari — VHS filmography shelf

A single-screen filmography hero for a fictional director, built to the attached spec:
plain HTML, CSS and vanilla JS. No framework, no build step, no libraries. One
`requestAnimationFrame` loop plus the Web Animations API — **no CSS keyframes and no
opacity fades anywhere** (every reveal is a mask slide, a clip or a scale).

## Files

| File | What it is |
| --- | --- |
| **`leon-vasari.html`** | The **single-file build** the spec asks for: markup, styles, script, all five font subsets and all 24 WebP assets inlined as data URIs. ~2.9 MB, works offline, works from `file://`. |
| `index.html` | The same page as separate files (links `styles.css`, `app.js`, `fonts/`, `assets/`) — easier to read and edit. Serve it over http (e.g. `python3 -m http.server`). |
| `styles.css` | Tokens, label system, top bar, decade tabs, 3D shelf faces, play ring, caption masks, arrows, footer, cursor, paper grain, detail sheet, responsive rules. |
| `app.js` | Film data, shelf builder, motion engine, caption swap, detail (paper sheet + ink blots), all inputs. |
| `fonts/fonts.css` | Inter Tight (variable 100–900), Newsreader 400 + 400 italic, Noto Sans JP 500 (subset of exactly the kana/kanji used), Noto Serif SC 700 (logo glyphs) — all base64 WOFF2. |
| `assets/*.webp` | The 24 CDN images, byte-for-byte mirrors: `*-s.webp` spines (142×840), `*-c.webp` covers (~474×900). |
| `build_single.py` | Rebuilds `leon-vasari.html` from the separate files. |

## Media

All 24 images are the originals from the Higgsfield CloudFront CDN described in the
prompt (`https://d2ol7oe51mr4n9.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/<id>.webp`),
downloaded and stored locally so the page never depends on the network. `app.js` keeps
the URL mapping in the comment block at the top.

## Behaviour

* **Shelf** — 12 films × 3 copies = 36 tapes, wrapped modulo 36 into −18…+18 and culled
  beyond `W/2 + 1.5d`. Spine width `142/840·H`, cover width `474/900·H`, gap `0.03H`,
  smooth `B(r)` push-apart so fractional scrolling never jumps.
* **Turning** — `o = smoothstep(max(0, 1 − |r|))` drives `rotateY(−90°o + tiltY·o)`,
  `rotateX`, `rotateZ(−4.5°o)`, `translateZ(0.2H·o)`, `translateY(−0.025H·o − 0.045H·lift)`;
  face shading is `o·.55` on the spine and `(1−o)·.5` on the cover.
* **Changing film** — spine click, arrows, decade tabs, wheel (both axes, snap after
  160 ms), drag (fast spring), ← → keys, Enter to open, Escape to close.
* **Caption** — three masks; new line slides from `dir × 105%`, old one leaves the other
  way, 650 ms `cubic-bezier(.2,.8,.2,1)`.
* **Cursor** — 58 px ring + dot + "OPEN / 開く" label, exponential follow; shrinks on
  spines, drops the dot over buttons, becomes a cobalt disc over the cover.
* **Detail** — the sheet grows out of the cover's projected rect
  (`clip-path: inset(... round 3px)` + `rotate(-4.5deg)` → full screen, 1050 ms
  `cubic-bezier(.76,0,.18,1)`), lines rise at `620 ms + i·75 ms`, and the poster bleeds
  in as seven `feTurbulence` + `feDisplacementMap` ink blots growing 0 → 720 over
  1250 ms each. Closing runs the sheet back into the current cover rect in 850 ms.
* **Reduced motion** — spring and lift become instant, caption swaps replace text,
  sheet open/close and text rises are 1 ms, ink starts fully grown.
* **Mobile (≤767px)** — `--H: min(60vw, 40svh)`, 64 px bar, smaller tabs/caption/arrows,
  single-column scrolling detail with the poster first at 46svh, no custom cursor,
  finger-drag scrubbing via `touch-action: pan-y`.
